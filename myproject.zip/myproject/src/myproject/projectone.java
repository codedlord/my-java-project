package myproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JSplitPane;
import javax.swing.JToggleButton;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import java.awt.Component;

import javax.swing.UIManager;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import java.awt.CardLayout;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;


import net.proteanit.sql.DbUtils;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.border.BevelBorder;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.print.PrinterException;

import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.border.MatteBorder;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.LineBorder;
import javax.swing.ListSelectionModel;
import com.toedter.calendar.JDayChooser;
import com.toedter.calendar.JCalendar;
import java.awt.Toolkit;
import javax.swing.border.EtchedBorder;
import java.awt.SystemColor;

public class projectone {

	private JFrame frame;
	private JLayeredPane layeredPane;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPanel panel_4;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField textField_3;
	private JTextField textField_4;
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					projectone window = new projectone();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection connection=null; 
	PreparedStatement pst=null;
	private JTextArea textArea;
	private JTextArea textArea_1;
	private JDateChooser dateChooser;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextArea textArea_2;
	private JTextArea textArea_2_1;
	private JDateChooser dateChooser_1_1;
	private JDateChooser dateChooser_1;
	private JTable table;
	private JTable table_1;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_27;
	private JTextField textField_28;
	private JTextField textField_29;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;
	private JTextField textField_33;
	private JTextField textField_34;
	private JTextField totals;
	private JTextField textField_36;
	private JTextField textField_37;
	private JButton btnNewButton_2;
	private JTextArea textArea_3;
	private JTextField textField_35;
	private JTextField textField_38;
	private JTextField textField_39;
	private JTextField textField_40;
	private JTextField textField_41;
	private JTextField textField_42;
	private JTextField textField_43;
	private JTextField textField_44;
	private JTextField textField_45;
	private JTextField textField_46;
	private JTextField textField_47;
	private JTextField textField_48;
	private JTextField textField_49;
	private JTextField textField_50;
	private JTextField textField_51;
	private JTextArea textArea_4;
	private JTextField textField_52;
	private JTextField textField_53;
	private JTextField textField_54;
	private JTextField textField_55;
	private JTextField textField_56;
	private JTextField textField_57;
	private JTextField textField_58;
	private JTextField textField_59;
	private JTextField textField_60;
	private JTextField textField_61;
	private JTextField textField_62;
	private JTextField textField_63;
	private JTextField textField_64;
	private JTextField textField_65;
	private JTextField textField_66;
	private JTextField textField_67;
	private JTable table_2;
	private JTextField textField_68;
	private JTextField textField_69;
	private JTextField textField_70;
	private JTextField textField_71;
	private JTextField textField_72;
	private JTextField textField_73;
	private JTextField textField_74;
	private JTextField textField_75;
	private JTextField textField_76;
	private JTextField textField_77;
	private JTextField textField_78;
	private JTextField textField_79;
	private JTextField textField_80;
	private JTextField textField_81;
	private JTextField textField_82;
	private JTextField textField_83;
	private JTextField textField_84;
	private JTextField textField_85;
	private JTable table_3;
	private JTable table_4;
	private JTextField textField_86;
	private JTextField textField_87;
	private JTextField textField_88;
	private JTextField textField_89;
	private JTextField textField_90;
	private JTextField textField_91;
	private JTextField textField_92;
	private JTextField textField_93;
	private JDateChooser dateChooser_5;
	private JTextArea textArea_8;
	public void switchPanel(JPanel pane) {
		layeredPane.removeAll();
		layeredPane.add(pane);
		layeredPane.repaint();
		layeredPane.revalidate();
		
		
	}

	/**
	 * Create the application.
	 */
	
	
	
	
	public projectone() {
		initialize();
		connection=connectiondb.dbconnect();
	}
	
	//control for the validation of textfield so that we can avoid emptyfield inside the database
	private boolean validateFields() {
	if(textField.getText().isEmpty()|textField_1.getText().isEmpty()|textField_2.getText().isEmpty()|textField_3.getText().isEmpty()|textField_4.getText().isEmpty()|textField_5.getText().isEmpty()|
		textField_6.getText().isEmpty()|textField_7.getText().isEmpty()|textField_8.getText().isEmpty()|textArea.getText().isEmpty()|textArea_1.getText().isEmpty()) {
		JOptionPane.showMessageDialog(null, "FIELD CANNOT BE EMPTY","EMPTY FIELD", JOptionPane.ERROR_MESSAGE);
		return false;
	}
	return true;
	}
	private boolean validateFieldtwo() {
		if(textField_12.getText().isEmpty()|textField_13.getText().isEmpty()|textField_14.getText().isEmpty()|textField_15.getText().isEmpty()|textField_16.getText().isEmpty()|textField_17.getText().isEmpty()|
			textField_18.getText().isEmpty()|textField_19.getText().isEmpty()|textArea_2.getText().isEmpty()|textArea_2_1.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "FIELD CANNOT BE EMPTY","EMPTY FIELD", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
	private boolean validateFieldthree() {
		if(textField_20.getText().isEmpty()|textField_21.getText().isEmpty()|textField_22.getText().isEmpty()|textField_23.getText().isEmpty()|textField_24.getText().isEmpty()|textField_25.getText().isEmpty()|
			textField_26.getText().isEmpty()|textField_27.getText().isEmpty()|textField_28.getText().isEmpty()|textField_29.getText().isEmpty()|textField_30.getText().isEmpty()|textField_31.getText().isEmpty()
			|textField_32.getText().isEmpty()|textField_33.getText().isEmpty()|textField_34.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "FIELD CANNOT BE EMPTY","EMPTY FIELD", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
	private boolean validateFieldfour() {
		if(textField_20.getText().isEmpty()|textField_21.getText().isEmpty()|textField_22.getText().isEmpty()|textField_23.getText().isEmpty()|textField_24.getText().isEmpty()|textField_25.getText().isEmpty()|
			textField_26.getText().isEmpty()|textField_27.getText().isEmpty()|textField_28.getText().isEmpty()|textField_29.getText().isEmpty()|textField_30.getText().isEmpty()|textField_31.getText().isEmpty()
			|textField_32.getText().isEmpty()|textField_33.getText().isEmpty()|textField_34.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "FIELD CANNOT BE EMPTY","EMPTY FIELD", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
	private boolean validateFieldfive() {
		if(textField_35.getText().isEmpty()|textField_38.getText().isEmpty()|textField_39.getText().isEmpty()|textField_40.getText().isEmpty()|textField_41.getText().isEmpty()|textField_42.getText().isEmpty()|
			textField_43.getText().isEmpty()|textField_44.getText().isEmpty()|textField_45.getText().isEmpty()|textField_46.getText().isEmpty()|textField_47.getText().isEmpty()|textField_48.getText().isEmpty()
			|textField_49.getText().isEmpty()|textField_50.getText().isEmpty()|textField_51.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "FIELD CANNOT BE EMPTY","EMPTY FIELD", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
	private boolean validateFieldsix() {
		if(textField_35.getText().isEmpty()|textField_38.getText().isEmpty()|textField_39.getText().isEmpty()|textField_40.getText().isEmpty()|textField_41.getText().isEmpty()|textField_42.getText().isEmpty()|
			textField_43.getText().isEmpty()|textField_44.getText().isEmpty()|textField_45.getText().isEmpty()|textField_46.getText().isEmpty()|textField_47.getText().isEmpty()|textField_48.getText().isEmpty()
			|textField_49.getText().isEmpty()|textField_50.getText().isEmpty()|textField_51.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "FIELD CANNOT BE EMPTY","EMPTY FIELD", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
	private boolean validateFieldseven() {
		if(textField_71.getText().isEmpty()|textField_72.getText().isEmpty()|textField_73.getText().isEmpty()|textField_74.getText().isEmpty()|textField_75.getText().isEmpty()|textField_76.getText().isEmpty()|
			textField_77.getText().isEmpty()|textField_78.getText().isEmpty()|textField_79.getText().isEmpty()|textField_80.getText().isEmpty()|textField_81.getText().isEmpty()|textField_82.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "FIELD CANNOT BE EMPTY","EMPTY FIELD", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
	private boolean validateFieldeight() {
		if(textField_71.getText().isEmpty()|textField_72.getText().isEmpty()|textField_73.getText().isEmpty()|textField_74.getText().isEmpty()|textField_75.getText().isEmpty()|textField_76.getText().isEmpty()|
			textField_77.getText().isEmpty()|textField_78.getText().isEmpty()|textField_79.getText().isEmpty()|textField_80.getText().isEmpty()|textField_81.getText().isEmpty()|textField_82.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "FIELD CANNOT BE EMPTY","EMPTY FIELD", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\USER\\workstation\\myproject\\src\\myproject\\user-login-authenticate-icon-vector-260nw-1236250177.jpg"));
		frame.setForeground(Color.WHITE);
		frame.setBackground(Color.WHITE);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 1370, 767);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setExtendedState(frame.MAXIMIZED_BOTH);
		
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.WHITE);
		panel.setBounds(10, 0, 218, 359);
		panel.setBackground(Color.WHITE);
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Controlpanel", TitledBorder.CENTER, TitledBorder.TOP, null, Color.LIGHT_GRAY));
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("Registration\r\n");
		btnNewButton.setForeground(Color.LIGHT_GRAY);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				switchPanel(panel_1);
			}
		});
		btnNewButton.setBounds(10, 26, 198, 58);
		panel.add(btnNewButton);
		
		JButton btnRecords = new JButton("Records");
		btnRecords.setBackground(Color.WHITE);
		btnRecords.setForeground(Color.LIGHT_GRAY);
		btnRecords.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				switchPanel(panel_2);
			}
		});
		btnRecords.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnRecords.setBounds(10, 90, 198, 58);
		panel.add(btnRecords);
		
		JButton btnBussarSection = new JButton("Bussar section");
		btnBussarSection.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				switchPanel(panel_3);
			}
		});
		btnBussarSection.setBackground(Color.WHITE);
		btnBussarSection.setForeground(Color.LIGHT_GRAY);
		btnBussarSection.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnBussarSection.setBounds(10, 155, 198, 58);
		panel.add(btnBussarSection);
		
		JButton btnAbout = new JButton("Result Section");
		btnAbout.setBackground(Color.WHITE);
		btnAbout.setForeground(Color.LIGHT_GRAY);
		btnAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				switchPanel(panel_4);
			}
		});
		btnAbout.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnAbout.setBounds(10, 220, 198, 58);
		panel.add(btnAbout);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(10, 289, 198, 58);
		panel.add(btnExit);
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnExit.setForeground(Color.LIGHT_GRAY);
		btnExit.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnExit.setBackground(Color.WHITE);
		
		layeredPane = new JLayeredPane();
		layeredPane.setForeground(Color.WHITE);
		layeredPane.setBackground(Color.WHITE);
		layeredPane.setBounds(225, 0, 1137, 741);
		frame.getContentPane().add(layeredPane);
		layeredPane.setLayout(new CardLayout(0, 0));
		
		
		panel_1 = new JPanel();
		panel_1.setForeground(Color.WHITE);
		layeredPane.add(panel_1, "name_239327367546237");
		panel_1.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setForeground(Color.LIGHT_GRAY);
		tabbedPane.setBackground(Color.WHITE);
		tabbedPane.setFont(new Font("Tahoma", Font.BOLD, 12));
		tabbedPane.setBounds(0, 0, 1137, 741);
		panel_1.add(tabbedPane);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBackground(Color.WHITE);
		panel_6.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		tabbedPane.addTab("NEW Student", null, panel_6, null);
		panel_6.setLayout(null);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(Color.WHITE);
		panel_5.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Biodata", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_5.setBounds(9, 229, 487, 461);
		panel_6.add(panel_5);
		panel_5.setLayout(null);
		
		JLabel lblFirstName = new JLabel("FirstName");
		lblFirstName.setBounds(9, 16, 143, 24);
		panel_5.add(lblFirstName);
		lblFirstName.setForeground(Color.LIGHT_GRAY);
		lblFirstName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		textField = new JTextField();
		textField.setBounds(230, 20, 247, 20);
		panel_5.add(textField);
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_1.requestFocus();
					
				}
			}
		});
		textField.setColumns(10);
		
		JLabel lblMiddleName = new JLabel("MiddleName");
		lblMiddleName.setBounds(9, 50, 175, 24);
		panel_5.add(lblMiddleName);
		lblMiddleName.setForeground(Color.LIGHT_GRAY);
		lblMiddleName.setBackground(Color.WHITE);
		lblMiddleName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		textField_1 = new JTextField();
		textField_1.setBounds(230, 54, 247, 20);
		panel_5.add(textField_1);
		textField_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_2.requestFocus();
			}
		}});
		textField_1.setColumns(10);
		
		JLabel lblLastName = new JLabel("LastName");
		lblLastName.setBounds(9, 85, 175, 24);
		panel_5.add(lblLastName);
		lblLastName.setForeground(Color.LIGHT_GRAY);
		lblLastName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		textField_2 = new JTextField();
		textField_2.setBounds(230, 85, 247, 20);
		panel_5.add(textField_2);
		textField_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					Component textArea_7 = null;
					textArea_7.requestFocus();
			}
		}});
		textField_2.setColumns(10);
		
		dateChooser = new JDateChooser();
		dateChooser.setBounds(230, 116, 247, 20);
		panel_5.add(dateChooser);
		
		JLabel lblDateOfBirth = new JLabel("Date Of Birth");
		lblDateOfBirth.setBounds(6, 120, 175, 24);
		panel_5.add(lblDateOfBirth);
		lblDateOfBirth.setForeground(Color.LIGHT_GRAY);
		lblDateOfBirth.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setBounds(9, 143, 175, 24);
		panel_5.add(lblGender);
		lblGender.setForeground(Color.LIGHT_GRAY);
		lblGender.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(230, 147, 247, 20);
		panel_5.add(comboBox_1);
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"SELECT GENDER", "MALE ", "FEMALE"}));
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(9, 193, 143, 24);
		panel_5.add(lblAddress);
		lblAddress.setForeground(Color.LIGHT_GRAY);
		lblAddress.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JLabel lblStateOfOrigin = new JLabel("State Of Origin");
		lblStateOfOrigin.setBounds(9, 308, 175, 24);
		panel_5.add(lblStateOfOrigin);
		lblStateOfOrigin.setForeground(Color.LIGHT_GRAY);
		lblStateOfOrigin.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		textField_3 = new JTextField();
		textField_3.setBounds(230, 312, 247, 20);
		panel_5.add(textField_3);
		textField_3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_4.requestFocus();
			}
			}
		});
		textField_3.setColumns(10);
		
		JLabel lblLga = new JLabel("LGA");
		lblLga.setBounds(9, 339, 151, 24);
		panel_5.add(lblLga);
		lblLga.setForeground(Color.LIGHT_GRAY);
		lblLga.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		textField_4 = new JTextField();
		textField_4.setBounds(230, 343, 247, 20);
		panel_5.add(textField_4);
		textField_4.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_5.requestFocus();
			}
			}
		});
		textField_4.setColumns(10);
		
		JLabel lblDisabilities = new JLabel("Disabilities");
		lblDisabilities.setBounds(9, 374, 189, 24);
		panel_5.add(lblDisabilities);
		lblDisabilities.setForeground(Color.LIGHT_GRAY);
		lblDisabilities.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(230, 372, 247, 20);
		panel_5.add(comboBox_2);
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"SELECT", "YES", "NO"}));
		
		JLabel lblRelationshipToStudent = new JLabel("Relationship To Student");
		lblRelationshipToStudent.setBounds(9, 277, 213, 24);
		panel_5.add(lblRelationshipToStudent);
		lblRelationshipToStudent.setForeground(Color.LIGHT_GRAY);
		lblRelationshipToStudent.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setBounds(230, 281, 247, 20);
		panel_5.add(comboBox_4);
		comboBox_4.setModel(new DefaultComboBoxModel(new String[] {"SELECT", "FATHER", "MOTHER", "AUNTY", "UNCLE", "GUIDIAN", "WARD"}));
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(230, 178, 247, 75);
		panel_5.add(scrollPane_2);
		
		textArea_8 = new JTextArea();
		textArea_8.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_3.requestFocus();
				}
			}
		});
		textArea_8.setLineWrap(true);
		scrollPane_2.setViewportView(textArea_8);
		
		JLabel lblBloodGroup = new JLabel("Blood Group");
		lblBloodGroup.setBounds(9, 407, 189, 30);
		panel_5.add(lblBloodGroup);
		lblBloodGroup.setForeground(Color.LIGHT_GRAY);
		lblBloodGroup.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setBounds(230, 403, 247, 20);
		panel_5.add(comboBox_3);
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"SELECT", "O+", "O-", "AB", "AB-"}));
		
		JPanel panel_12 = new JPanel();
		panel_12.setBackground(Color.WHITE);
		panel_12.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Guidian Details", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_12.setBounds(498, 234, 624, 358);
		panel_6.add(panel_12);
		panel_12.setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(9, 16, 143, 24);
		panel_12.add(lblName);
		lblName.setForeground(Color.LIGHT_GRAY);
		lblName.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JLabel lblPhoneNumber = new JLabel("Phone Number 1");
		lblPhoneNumber.setBounds(6, 51, 213, 24);
		panel_12.add(lblPhoneNumber);
		lblPhoneNumber.setForeground(Color.LIGHT_GRAY);
		lblPhoneNumber.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JLabel lblPhoneNumber_1 = new JLabel("Phone Number 2");
		lblPhoneNumber_1.setBounds(9, 86, 181, 24);
		panel_12.add(lblPhoneNumber_1);
		lblPhoneNumber_1.setForeground(Color.LIGHT_GRAY);
		lblPhoneNumber_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(9, 117, 143, 24);
		panel_12.add(lblEmail);
		lblEmail.setForeground(Color.LIGHT_GRAY);
		lblEmail.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JLabel lblAddress_1 = new JLabel("Address");
		lblAddress_1.setBounds(9, 210, 143, 24);
		panel_12.add(lblAddress_1);
		lblAddress_1.setForeground(Color.LIGHT_GRAY);
		lblAddress_1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		JLabel lblMoi = new JLabel(" MOI");
		lblMoi.setBounds(9, 323, 143, 24);
		panel_12.add(lblMoi);
		lblMoi.setForeground(Color.LIGHT_GRAY);
		lblMoi.setFont(new Font("Times New Roman", Font.BOLD, 18));
		
		textField_5 = new JTextField();
		textField_5.setBounds(367, 20, 247, 20);
		panel_12.add(textField_5);
		textField_5.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_6.requestFocus();
			}
			}
		});
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(367, 55, 247, 20);
		panel_12.add(textField_6);
		textField_6.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_7.requestFocus();
			}
			}
		});
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(367, 90, 247, 20);
		panel_12.add(textField_7);
		textField_7.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_8.requestFocus();
			}
			}
		});
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBounds(367, 121, 247, 20);
		panel_12.add(textField_8);
		textField_8.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textArea_1.requestFocus();
			}
			}
		});
		textField_8.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(367, 327, 247, 20);
		panel_12.add(comboBox);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"SELECT ONE", "ID CARD", "DRIVER LIENCE", "NIN", "VOTERS CARD"}));
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(371, 162, 243, 134);
		panel_12.add(scrollPane_3);
		
		textArea_1 = new JTextArea();
		scrollPane_3.setViewportView(textArea_1);
		textArea_1.setWrapStyleWord(true);
		textArea_1.setLineWrap(true);
		textArea_1.setBackground(Color.WHITE);
		textArea_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField.requestFocus();
			}
			}
		});
		
		JSeparator separator = new JSeparator();
		separator.setBounds(489, 229, -6, 333);
		panel_6.add(separator);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\USER\\Documents\\returning.png"));
		lblNewLabel_2.setBounds(469, 26, 254, 192);
		panel_6.add(lblNewLabel_2);
		
		textArea = new JTextArea();
		textArea.setBounds(192, 405, 245, 70);
		panel_6.add(textArea);
		textArea.setWrapStyleWord(true);
		textArea.setLineWrap(true);
		textArea.setBackground(Color.LIGHT_GRAY);
		
		JPanel panel_40 = new JPanel();
		panel_40.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_40.setBounds(506, 644, 300, 52);
		panel_6.add(panel_40);
		panel_40.setLayout(null);
		//control code for storing student data into the database
		JButton btnClear_1 = new JButton("Register");
		btnClear_1.setBounds(6, 16, 284, 30);
		panel_40.add(btnClear_1);
		btnClear_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//call the above validatefield method when the register button is clicked
				if(validateFields()) {
				String sql="INSERT INTO Registration(FirstName,SecondName,MiddleName,DOB,GENDER,ADDRESS,SOO,LGA,DISABILITY,BLOODGROUP,GuidainaName,PhoneNumberone,PhoneNumbertwo,email,GuidianAddress,MODEOFIDENTIFICATION,RELATIONWITHSTUDENT)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				try {
					pst=connection.prepareStatement(sql);
				pst.setString(1, textField.getText());
				pst.setString(2, textField.getText());
				pst.setString(3, textField_2.getText());
				pst.setString(4, ((JTextField)dateChooser.getDateEditor().getUiComponent()).getText());
				String value=comboBox_1.getSelectedItem().toString();
				pst.setString(5, value);
				pst.setString(6, textArea_8.getText());
				pst.setString(7, textField_3.getText());
				pst.setString(8,textField_4.getText() );
				String valueone=comboBox_2.getSelectedItem().toString();
				pst.setString(9, valueone);
				String valuetwo=comboBox_3.getSelectedItem().toString();
				pst.setString(10, valuetwo);
				pst.setString(11, textField_5.getText());
				pst.setString(12, textField_6.getText());
				pst.setString(13, textField_7.getText());
				pst.setString(14, textField_8.getText());
				pst.setString(15, textArea_1.getText());
				String valuethree=comboBox.getSelectedItem().toString();
				pst.setString(16, valuethree);
				String valuefour=comboBox_4.getSelectedItem().toString();
				pst.setString(17, valuefour);
				
				
				
				pst.execute();
				JOptionPane.showMessageDialog(null, "inserted");
				} catch (SQLException e) {
					JOptionPane.showMessageDialog(null, e);

					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
			}
		});
		
		JPanel panel_41 = new JPanel();
		panel_41.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_41.setBounds(824, 644, 298, 52);
		panel_6.add(panel_41);
		panel_41.setLayout(null);
		
		JButton btnClear = new JButton("Clear");
		btnClear.setBounds(6, 16, 282, 30);
		panel_41.add(btnClear);
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dateChooser.setCalendar(null);
				comboBox_1.setSelectedItem(null);
				comboBox_2.setSelectedItem(null);
				comboBox_3.setSelectedItem(null);
				comboBox.setSelectedItem(null);
				comboBox_4.setSelectedItem(null);
				textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				textField_3.setText(null);
				textField_4.setText(null);
				textField_5.setText(null);
				textField_6.setText(null);
				textField_7.setText(null);
				textField_8.setText(null);
				textArea.setText(null);
				textArea_1.setText(null);
				textArea_8.setText(null);
				
			}
		});
		textArea.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_3.requestFocus();
			}
			}
		});
		
		JPanel panel_7 = new JPanel();
		panel_7.setBackground(Color.WHITE);
		tabbedPane.addTab("Staff", null, panel_7, null);
		panel_7.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(489, 15, 225, 198);
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\USER\\workstation\\myproject\\src\\myproject\\img.jpg"));
		panel_7.add(lblNewLabel_3);
		
		JPanel panel_42 = new JPanel();
		panel_42.setBackground(Color.WHITE);
		panel_42.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Biodata", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_42.setBounds(4, 233, 483, 456);
		panel_7.add(panel_42);
		panel_42.setLayout(null);
		
		JLabel lblFirstname_1 = new JLabel("FirstName");
		lblFirstname_1.setBounds(6, 16, 110, 26);
		panel_42.add(lblFirstname_1);
		lblFirstname_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_1 = new JLabel("MiddleName");
		lblFirstname_1_1.setBounds(6, 53, 110, 26);
		panel_42.add(lblFirstname_1_1);
		lblFirstname_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_2 = new JLabel("LastName");
		lblFirstname_1_2.setBounds(6, 90, 110, 26);
		panel_42.add(lblFirstname_1_2);
		lblFirstname_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_2_1 = new JLabel("Date Of Birth");
		lblFirstname_1_2_1.setBounds(6, 127, 127, 26);
		panel_42.add(lblFirstname_1_2_1);
		lblFirstname_1_2_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_2_1_1 = new JLabel("Gender");
		lblFirstname_1_2_1_1.setBounds(6, 166, 110, 26);
		panel_42.add(lblFirstname_1_2_1_1);
		lblFirstname_1_2_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_2_1_1_1 = new JLabel("Marrital Status");
		lblFirstname_1_2_1_1_1.setBounds(6, 203, 127, 26);
		panel_42.add(lblFirstname_1_2_1_1_1);
		lblFirstname_1_2_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_2_1_1_1_1 = new JLabel("PhoneNumber");
		lblFirstname_1_2_1_1_1_1.setBounds(6, 240, 127, 26);
		panel_42.add(lblFirstname_1_2_1_1_1_1);
		lblFirstname_1_2_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_2_1_1_1_1_1 = new JLabel("PhoneNumber");
		lblFirstname_1_2_1_1_1_1_1.setBounds(6, 277, 127, 26);
		panel_42.add(lblFirstname_1_2_1_1_1_1_1);
		lblFirstname_1_2_1_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_2_1_1_1_1_1_1 = new JLabel("Address");
		lblFirstname_1_2_1_1_1_1_1_1.setBounds(6, 333, 127, 26);
		panel_42.add(lblFirstname_1_2_1_1_1_1_1_1);
		lblFirstname_1_2_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		textField_12 = new JTextField();
		textField_12.setBounds(278, 21, 195, 20);
		panel_42.add(textField_12);
		textField_12.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_13.requestFocus();
			}
		}});
		textField_12.setColumns(10);
		
		textField_13 = new JTextField();
		textField_13.setBounds(278, 58, 195, 20);
		panel_42.add(textField_13);
		textField_13.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_14.requestFocus();
			}
		}});
		textField_13.setColumns(10);
		
		textField_14 = new JTextField();
		textField_14.setBounds(278, 95, 195, 20);
		panel_42.add(textField_14);
		textField_14.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_15.requestFocus();
			}
		}});
		textField_14.setColumns(10);
		
		dateChooser_1 = new JDateChooser();
		dateChooser_1.setBounds(278, 127, 195, 20);
		panel_42.add(dateChooser_1);
		
		JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setBounds(278, 171, 195, 20);
		panel_42.add(comboBox_5);
		comboBox_5.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		
		JComboBox comboBox_5_1 = new JComboBox();
		comboBox_5_1.setBounds(278, 208, 195, 20);
		panel_42.add(comboBox_5_1);
		comboBox_5_1.setModel(new DefaultComboBoxModel(new String[] {"Single", "Married"}));
		
		textField_15 = new JTextField();
		textField_15.setBounds(278, 245, 195, 20);
		panel_42.add(textField_15);
		textField_15.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_16.requestFocus();
			}
		}});
		textField_15.setColumns(10);
		
		textField_16 = new JTextField();
		textField_16.setBounds(278, 282, 195, 20);
		panel_42.add(textField_16);
		textField_16.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textArea_2.requestFocus();
			}
		}});
		textField_16.setColumns(10);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(264, 313, 209, 117);
		panel_42.add(scrollPane_4);
		
		textArea_2 = new JTextArea();
		scrollPane_4.setViewportView(textArea_2);
		textArea_2.setLineWrap(true);
		textArea_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_17.requestFocus();
			}
		}});
		textArea_2.setBackground(Color.WHITE);
		
		JLabel label = new JLabel("");
		label.setBounds(10, 360, 46, 14);
		panel_7.add(label);
		
		JPanel panel_43 = new JPanel();
		panel_43.setBackground(Color.WHITE);
		panel_43.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Official Use Only", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_43.setBounds(491, 239, 631, 135);
		panel_7.add(panel_43);
		panel_43.setLayout(null);
		
		JLabel lblFirstname_1_3 = new JLabel("Moi");
		lblFirstname_1_3.setBounds(22, 16, 110, 26);
		panel_43.add(lblFirstname_1_3);
		lblFirstname_1_3.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_3_1 = new JLabel("Appointment Date");
		lblFirstname_1_3_1.setBounds(6, 61, 151, 26);
		panel_43.add(lblFirstname_1_3_1);
		lblFirstname_1_3_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_3_1_1 = new JLabel("Contract Type");
		lblFirstname_1_3_1_1.setBounds(6, 98, 151, 26);
		panel_43.add(lblFirstname_1_3_1_1);
		lblFirstname_1_3_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JComboBox comboBox_6 = new JComboBox();
		comboBox_6.setBounds(374, 21, 247, 20);
		panel_43.add(comboBox_6);
		comboBox_6.setModel(new DefaultComboBoxModel(new String[] {"SELECT ONE", "ID CARD", "DRIVER LIENCE", "NIN", "VOTERS CARD"}));
		
		dateChooser_1_1 = new JDateChooser();
		dateChooser_1_1.setBounds(374, 67, 247, 20);
		panel_43.add(dateChooser_1_1);
		
		JComboBox comboBox_6_1 = new JComboBox();
		comboBox_6_1.setBounds(374, 103, 247, 20);
		panel_43.add(comboBox_6_1);
		comboBox_6_1.setModel(new DefaultComboBoxModel(new String[] {"Full Time", "Part Time"}));
		
		JPanel panel_44 = new JPanel();
		panel_44.setBackground(Color.WHITE);
		panel_44.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Refree", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_44.setBounds(491, 383, 631, 256);
		panel_7.add(panel_44);
		panel_44.setLayout(null);
		
		JLabel lblFirstname_1_3_1_1_1 = new JLabel("Name");
		lblFirstname_1_3_1_1_1.setBounds(6, 16, 151, 26);
		panel_44.add(lblFirstname_1_3_1_1_1);
		lblFirstname_1_3_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_3_1_1_2 = new JLabel("Occupation");
		lblFirstname_1_3_1_1_2.setBounds(6, 53, 151, 26);
		panel_44.add(lblFirstname_1_3_1_1_2);
		lblFirstname_1_3_1_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_3_1_1_3 = new JLabel("PhoneNumber");
		lblFirstname_1_3_1_1_3.setBounds(6, 90, 151, 26);
		panel_44.add(lblFirstname_1_3_1_1_3);
		lblFirstname_1_3_1_1_3.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		JLabel lblFirstname_1_3_1_1_3_1 = new JLabel("Address");
		lblFirstname_1_3_1_1_3_1.setBounds(6, 157, 151, 26);
		panel_44.add(lblFirstname_1_3_1_1_3_1);
		lblFirstname_1_3_1_1_3_1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		
		textField_17 = new JTextField();
		textField_17.setBounds(374, 21, 247, 20);
		panel_44.add(textField_17);
		textField_17.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_18.requestFocus();
			}
		}});
		textField_17.setColumns(10);
		
		textField_18 = new JTextField();
		textField_18.setBounds(374, 58, 247, 20);
		panel_44.add(textField_18);
		textField_18.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_19.requestFocus();
		}}});
		textField_18.setColumns(10);
		
		textField_19 = new JTextField();
		textField_19.setBounds(374, 95, 247, 20);
		panel_44.add(textField_19);
		textField_19.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textArea_2_1.requestFocus();
			}
		}});
		textField_19.setColumns(10);
		
		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(378, 132, 243, 113);
		panel_44.add(scrollPane_5);
		
		textArea_2_1 = new JTextArea();
		scrollPane_5.setViewportView(textArea_2_1);
		textArea_2_1.setLineWrap(true);
		textArea_2_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_12.requestFocus();
			}
		}});
		textArea_2_1.setBackground(Color.WHITE);
		
		JPanel panel_45 = new JPanel();
		panel_45.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_45.setBounds(501, 650, 264, 45);
		panel_7.add(panel_45);
		panel_45.setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Register");
		btnNewButton_1.setBounds(6, 16, 252, 23);
		panel_45.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(validateFieldtwo()) {
				String sql="INSERT INTO staffdb(FirstName,MiddleName,LastName,DateOfBirth,Gender,MaritalStatus,PhoneNumberOne,PhoneNumberTwo,Address,MOI,AppointmentDate,ContractType,ReferalName,Occupation,PhoneNumber,ReferalAddress)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				try {
					pst=connection.prepareStatement(sql);
					pst.setString(1, textField_12.getText());
					pst.setString(2, textField_13.getText());
					pst.setString(3, textField_14.getText());
					pst.setString(4, ((JTextField)dateChooser_1.getDateEditor().getUiComponent()).getText());
					String value=comboBox_5.getSelectedItem().toString();
					pst.setString(5, value);
					String valueone=comboBox_5_1.getSelectedItem().toString();
					pst.setString(6, valueone);
					pst.setString(7, textField_15.getText());
					pst.setString(8, textField_16.getText());
					pst.setString(9, textArea_2.getText());
					String valuetwo=comboBox_6.getSelectedItem().toString();
					pst.setString(10, valuetwo);
					pst.setString(11, ((JTextField)dateChooser_1_1.getDateEditor().getUiComponent()).getText());
					String valuethree=comboBox_6_1.getSelectedItem().toString();
					pst.setString(12, valuethree);
					pst.setString(13, textField_17.getText());
					pst.setString(14, textField_18.getText());
					pst.setString(15, textField_19.getText());
					pst.setString(16, textArea_2_1.getText());
					pst.execute();
					JOptionPane.showMessageDialog(null, "inserted");
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e);

				}
			}
		}});
		
		JPanel panel_46 = new JPanel();
		panel_46.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_46.setBounds(834, 650, 264, 45);
		panel_7.add(panel_46);
		panel_46.setLayout(null);
		
		JButton btnNewButton_1_1 = new JButton("Clear");
		btnNewButton_1_1.setBounds(6, 16, 252, 23);
		panel_46.add(btnNewButton_1_1);
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField_12.setText(null);
				textField_13.setText(null);
				textField_14.setText(null);
				textField_15.setText(null);
				textField_16.setText(null);
				textField_17.setText(null);
				textField_18.setText(null);
				textField_19.setText(null);
				dateChooser_1.setCalendar(null);
				comboBox_5.setSelectedItem(null);
				dateChooser_1_1.setCalendar(null);
				comboBox_5_1.setSelectedItem(null);
				comboBox_6.setSelectedItem(null);
				comboBox_6_1.setSelectedItem(null);
				textArea_2.setText(null);
				textArea_2_1.setText(null);
				
				
			}
		});
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		panel_2.setForeground(Color.WHITE);
		layeredPane.add(panel_2, "name_239341562794451");
		panel_2.setLayout(null);
		
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(0, 0, 1137, 741);
		tabbedPane_1.setBackground(Color.WHITE);
		tabbedPane_1.setForeground(Color.WHITE);
		panel_2.add(tabbedPane_1);
		
		JPanel panel_8 = new JPanel();
		panel_8.setForeground(Color.WHITE);
		panel_8.setBackground(Color.WHITE);
		panel_8.setBorder(null);
		tabbedPane_1.addTab("Student Records", null, panel_8, null);
		panel_8.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setViewportBorder(null);
		scrollPane.setBounds(0, 0, 1132, 668);
		panel_8.add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Tahoma", Font.BOLD, 12));
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setFillsViewportHeight(true);
		table.setForeground(Color.BLACK);
		table.setBackground(Color.WHITE);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""
			}
		));
		scrollPane.setViewportView(table);
		
		JButton btnLoad = new JButton("Load Database");
		btnLoad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query="select FirstName,SecondName,MiddleName,DOB,GENDER,ADDRESS,SOO,LGA,DISABILITY,BLOODGROUP,GuidainaName,PhoneNumberone,PhoneNumbertwo,email,GuidianAddress,MODEOFIDENTIFICATION,RELATIONWITHSTUDENT from Registration";
					pst=connection.prepareStatement(query);
					ResultSet rs=pst.executeQuery();
				table.setModel(DbUtils.resultSetToTableModel(rs));
					
					
				}catch(Exception e) {
					e.printStackTrace();
					
				}
			}
			});
		btnLoad.setBounds(534, 679, 132, 23);
		panel_8.add(btnLoad);
		
		textField_69 = new JTextField();
		textField_69.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				try {
					String query="select FirstName,SecondName,MiddleName,DOB,GENDER,ADDRESS,SOO,LGA,DISABILITY,BLOODGROUP,GuidainaName,PhoneNumberone,PhoneNumbertwo,email,GuidianAddress,MODEOFIDENTIFICATION,RELATIONWITHSTUDENT from  Registration where FirstName=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1, textField_69.getText());
					ResultSet rs=pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		textField_69.setBounds(10, 679, 260, 20);
		panel_8.add(textField_69);
		textField_69.setColumns(10);
		
		JLabel lblSearch_1 = new JLabel("Search");
		lblSearch_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblSearch_1.setBounds(280, 679, 89, 18);
		panel_8.add(lblSearch_1);
		
		JPanel panel_9 = new JPanel();
		panel_9.setForeground(Color.WHITE);
		panel_9.setBackground(Color.WHITE);
		tabbedPane_1.addTab("Staff Records", null, panel_9, null);
		panel_9.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setViewportBorder(null);
		scrollPane_1.setBounds(0, 0, 1132, 667);
		panel_9.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		table_1.setFillsViewportHeight(true);
		table_1.setForeground(Color.BLACK);
		table_1.setBackground(Color.WHITE);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""
			}
		));
		scrollPane_1.setViewportView(table_1);
		
		JButton btnLoad_1 = new JButton("Load Database");
		btnLoad_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query="select FirstName,MiddleName,LastName,DateOfBirth,Gender,MaritalStatus,PhoneNumberOne,PhoneNumberTwo,Address,MOI,AppointmentDate,ContractType,ReferalName,Occupation,PhoneNumber,ReferalAddress from staffdb";
					pst=connection.prepareStatement(query);
					ResultSet rs=pst.executeQuery();
				table_1.setModel(DbUtils.resultSetToTableModel(rs));
					
					
				}catch(Exception e) {
					e.printStackTrace();
					
				}
			}
		});
		btnLoad_1.setBounds(546, 677, 137, 23);
		panel_9.add(btnLoad_1);
		
		textField_70 = new JTextField();
		textField_70.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				try {
					String query="select FirstName,MiddleName,LastName,DateOfBirth,Gender,MaritalStatus,PhoneNumberOne,PhoneNumberTwo,Address,MOI,AppointmentDate,ContractType,ReferalName,Occupation,PhoneNumber,ReferalAddress  from staffdb where FirstName=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1, textField_70.getText());
					ResultSet rs=pst.executeQuery();
					table_1.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		textField_70.setBounds(10, 678, 259, 20);
		panel_9.add(textField_70);
		textField_70.setColumns(10);
		
		JLabel lblSearch_2 = new JLabel("Search");
		lblSearch_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblSearch_2.setBounds(279, 678, 89, 18);
		panel_9.add(lblSearch_2);
		
		JPanel panel_13 = new JPanel();
		panel_13.setForeground(Color.BLACK);
		panel_13.setBackground(Color.WHITE);
		tabbedPane_1.addTab("Student Result", null, panel_13, null);
		panel_13.setLayout(null);
		
		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(0, 0, 1132, 668);
		panel_13.add(scrollPane_7);
		
		table_2 = new JTable();
		table_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		table_2.setFillsViewportHeight(true);
		table_2.setColumnSelectionAllowed(true);
		table_2.setCellSelectionEnabled(true);
		table_2.setEnabled(false);
		table_2.setRowSelectionAllowed(false);
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""
			}
		));
		scrollPane_7.setViewportView(table_2);
		
		JButton btnNewButton_4 = new JButton("Load Database");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query="select FirstName,MiddleName,LastName,Term,DateOfResumption,Mathematics,English,Chemistry,Physic,Biology,Geography,Fmathematics,Government,BusinessStudies,FinancialAccount,Commerce,Computer,SubjectTaken,ScoreForTerm,ScoreObtain,Average from resultdb";
					pst=connection.prepareStatement(query);
					ResultSet rs=pst.executeQuery();
					table_2.setModel(DbUtils.resultSetToTableModel(rs));
					
					
				}catch(Exception e) {
					e.printStackTrace();
					
				}
				
			}
		});
		btnNewButton_4.setBounds(603, 679, 134, 23);
		panel_13.add(btnNewButton_4);
		
		textField_68 = new JTextField();
		textField_68.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				try {
					String query="select FirstName,MiddleName,LastName,Term,Mathematics,English,Chemistry,Physic,Biology,Geography,Fmathematics,Government,BusinessStudies,FinancialAccount,Commerce,Computer from  resultdb where FirstName=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1, textField_68.getText());
					ResultSet rs=pst.executeQuery();
					table_2.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		textField_68.setBounds(10, 680, 249, 20);
		panel_13.add(textField_68);
		textField_68.setColumns(10);
		
		JLabel lblSearch = new JLabel("Search");
		lblSearch.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblSearch.setBounds(269, 679, 94, 18);
		panel_13.add(lblSearch);
		
		JPanel panel_33 = new JPanel();
		tabbedPane_1.addTab("Returning Student Payment", null, panel_33, null);
		panel_33.setLayout(null);
		
		JScrollPane scrollPane_9 = new JScrollPane();
		scrollPane_9.setBounds(10, 11, 1132, 660);
		panel_33.add(scrollPane_9);
		
		table_3 = new JTable();
		table_3.setFillsViewportHeight(true);
		table_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		table_3.setRowSelectionAllowed(false);
		table_3.setEnabled(false);
		table_3.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""
			}
		));
		scrollPane_9.setViewportView(table_3);
		
		JButton btnLoad_2 = new JButton("Load Database");
		btnLoad_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query="select FirstName,LastName,MiddleName,DateOfPayment,TypeOfPayment,Tuition,DevelopmentFee,LessonFee,NoteBook,clubDues,MssnDues,FcfDues,Mercelinous,Ptalevy,TotalFee,Expectedfee,Balance from returndb";
					pst=connection.prepareStatement(query);
					ResultSet rs=pst.executeQuery();
				table_3.setModel(DbUtils.resultSetToTableModel(rs));
					
					
				}catch(Exception e) {
					e.printStackTrace();
					
				}
			}
		});
		btnLoad_2.setBounds(580, 679, 157, 23);
		panel_33.add(btnLoad_2);
		
		textField_86 = new JTextField();
		textField_86.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				try {
					String query="select FirstName,LastName,MiddleName,DateOfPayment,TypeOfPayment,Tuition,DevelopmentFee,LessonFee,NoteBook,clubDues,MssnDues,FcfDues,Mercelinous,Ptalevy,TotalFee,Expectedfee,Balance from  returndb where FirstName=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1, textField_86.getText());
					ResultSet rs=pst.executeQuery();
					table_3.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		textField_86.setBounds(20, 680, 270, 20);
		panel_33.add(textField_86);
		textField_86.setColumns(10);
		
		JLabel lblSearch_3 = new JLabel("Search");
		lblSearch_3.setBounds(328, 682, 83, 14);
		panel_33.add(lblSearch_3);
		
		JPanel panel_34 = new JPanel();
		tabbedPane_1.addTab("New Student Payment", null, panel_34, null);
		panel_34.setLayout(null);
		
		JScrollPane scrollPane_10 = new JScrollPane();
		scrollPane_10.setBounds(0, 0, 1132, 668);
		panel_34.add(scrollPane_10);
		
		table_4 = new JTable();
		table_4.setFillsViewportHeight(true);
		table_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		scrollPane_10.setViewportView(table_4);
		
		JButton btnLoad_3 = new JButton("Load Database");
		btnLoad_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String query="select FirstName,LastName,MiddleName,Typeofpayment,Dateofpayment,Term,Tuition,Developmentlevy,Uniform,Sport,Form,Notebook,Cardigan,Club,Mssn,Fcf,Merce,Pta,Total,Expectedfee,Balance from npaymentdb";
					pst=connection.prepareStatement(query);
					ResultSet rs=pst.executeQuery();
				table_4.setModel(DbUtils.resultSetToTableModel(rs));
					
					
				}catch(Exception e) {
					e.printStackTrace();
					
				}
			}
		});
		btnLoad_3.setBounds(566, 679, 135, 23);
		panel_34.add(btnLoad_3);
		
		textField_87 = new JTextField();
		textField_87.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				try {
					String query="select FirstName,LastName,MiddleName,Typeofpayment,Dateofpayment,Term,Tuition,Developmentlevy,Uniform,Sport,Form,Notebook,Cardigan,Club,Mssn,Fcf,Merce,Pta,Total,Expectedfee,Balance from  npaymentdb where FirstName=?";
					PreparedStatement pst=connection.prepareStatement(query);
					pst.setString(1, textField_87.getText());
					ResultSet rs=pst.executeQuery();
					table_4.setModel(DbUtils.resultSetToTableModel(rs));
					pst.close();
				}catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		textField_87.setBounds(10, 680, 263, 20);
		panel_34.add(textField_87);
		textField_87.setColumns(10);
		
		JLabel lblSearch_4 = new JLabel("Search");
		lblSearch_4.setBounds(303, 683, 130, 14);
		panel_34.add(lblSearch_4);
		
		panel_3 = new JPanel();
		layeredPane.add(panel_3, "name_239361168574940");
		panel_3.setLayout(null);
		
		JTabbedPane tabbedPane_2 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_2.setBackground(Color.WHITE);
		tabbedPane_2.setBounds(0, 0, 1137, 730);
		panel_3.add(tabbedPane_2);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBackground(Color.WHITE);
		tabbedPane_2.addTab("New Student Payment", null, panel_10, null);
		panel_10.setLayout(null);
		
		JPanel panel_14 = new JPanel();
		panel_14.setBackground(Color.WHITE);
		panel_14.setBounds(10, 11, 562, 207);
		panel_14.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Biodata", TitledBorder.CENTER, TitledBorder.TOP, null, Color.CYAN));
		panel_10.add(panel_14);
		panel_14.setLayout(null);
		
		JLabel lblFirstname_2 = new JLabel("FirstName");
		lblFirstname_2.setBounds(20, 5, 136, 31);
		panel_14.add(lblFirstname_2);
		lblFirstname_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_1 = new JLabel("LastName");
		lblFirstname_2_1.setBounds(20, 33, 136, 31);
		panel_14.add(lblFirstname_2_1);
		lblFirstname_2_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_2 = new JLabel("MiddleName");
		lblFirstname_2_2.setBounds(20, 67, 136, 31);
		panel_14.add(lblFirstname_2_2);
		lblFirstname_2_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		textField_20 = new JTextField();
		textField_20.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_21.requestFocus();
		}
			
			}
		});
		textField_20.setBounds(394, 11, 158, 20);
		panel_14.add(textField_20);
		textField_20.setColumns(10);
		
		textField_21 = new JTextField();
		textField_21.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_22.requestFocus();
		}
			
		}
		});
		textField_21.setColumns(10);
		textField_21.setBounds(394, 39, 158, 20);
		panel_14.add(textField_21);
		
		textField_22 = new JTextField();
		textField_22.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_23.requestFocus();
		}
			

			}
		});
		textField_22.setColumns(10);
		textField_22.setBounds(394, 67, 158, 20);
		panel_14.add(textField_22);
		
		JLabel lblFirstname_2_2_1 = new JLabel("Type Of Payment");
		lblFirstname_2_2_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFirstname_2_2_1.setBounds(20, 98, 136, 31);
		panel_14.add(lblFirstname_2_2_1);
		
		JLabel lblFirstname_2_2_1_1 = new JLabel("Date Of Payment");
		lblFirstname_2_2_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFirstname_2_2_1_1.setBounds(20, 130, 136, 31);
		panel_14.add(lblFirstname_2_2_1_1);
		
		JLabel lblFirstname_2_2_1_2 = new JLabel("Term");
		lblFirstname_2_2_1_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFirstname_2_2_1_2.setBounds(20, 157, 136, 31);
		panel_14.add(lblFirstname_2_2_1_2);
		
		JComboBox comboBox_7 = new JComboBox();
		comboBox_7.setModel(new DefaultComboBoxModel(new String[] {"Select", "Full Payment", "Half Payment"}));
		comboBox_7.setBounds(394, 98, 158, 20);
		panel_14.add(comboBox_7);
		
		JDateChooser dateChooser_2 = new JDateChooser();
		dateChooser_2.setBounds(394, 130, 158, 20);
		panel_14.add(dateChooser_2);
		
		JComboBox comboBox_8 = new JComboBox();
		comboBox_8.setModel(new DefaultComboBoxModel(new String[] {"Select", "First Term", "Second Term", "Third Term"}));
		comboBox_8.setBounds(394, 168, 158, 20);
		panel_14.add(comboBox_8);
		
		JPanel panel_15 = new JPanel();
		panel_15.setBackground(Color.WHITE);
		panel_15.setBounds(10, 229, 562, 228);
		panel_15.setBorder(new TitledBorder(null, "New Student Tuition", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panel_10.add(panel_15);
		panel_15.setLayout(null);
		
		JLabel lblTuitionFee = new JLabel("Tuition Fee");
		lblTuitionFee.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblTuitionFee.setBounds(25, 12, 84, 32);
		panel_15.add(lblTuitionFee);
		
		JLabel lblDevelopmentFee = new JLabel("Development Fee");
		lblDevelopmentFee.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblDevelopmentFee.setBounds(25, 43, 163, 32);
		panel_15.add(lblDevelopmentFee);
		
		JLabel lblForm = new JLabel("Form");
		lblForm.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblForm.setBounds(25, 140, 163, 25);
		panel_15.add(lblForm);
		
		JLabel lblNotebook = new JLabel("NoteBook");
		lblNotebook.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNotebook.setBounds(25, 167, 163, 32);
		panel_15.add(lblNotebook);
		
		JLabel lblUniformPairs = new JLabel("UniForm(2 pairs)");
		lblUniformPairs.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblUniformPairs.setBounds(25, 78, 163, 25);
		panel_15.add(lblUniformPairs);
		
		JLabel lblSportware = new JLabel("SportWare");
		lblSportware.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblSportware.setBounds(25, 109, 163, 25);
		panel_15.add(lblSportware);
		
		JLabel lblCardiganPair = new JLabel("Cardigan(1 pair)");
		lblCardiganPair.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblCardiganPair.setBounds(25, 198, 163, 25);
		panel_15.add(lblCardiganPair);
		
		textField_23 = new JTextField();
		textField_23.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_24.requestFocus();
		}
			

			}
		});
		textField_23.setBounds(382, 19, 170, 20);
		panel_15.add(textField_23);
		textField_23.setColumns(10);
		
		textField_24 = new JTextField();
		textField_24.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_25.requestFocus();
		}
			
	
			}
		});
		textField_24.setColumns(10);
		textField_24.setBounds(382, 50, 170, 20);
		panel_15.add(textField_24);
		
		textField_25 = new JTextField();
		textField_25.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_27.requestFocus();
		}
			
			}
		});
		textField_25.setColumns(10);
		textField_25.setBounds(382, 81, 170, 20);
		panel_15.add(textField_25);
		
		textField_26 = new JTextField();
		textField_26.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_28.requestFocus();
		}
			
		}
			
		});
		textField_26.setColumns(10);
		textField_26.setBounds(382, 143, 170, 20);
		panel_15.add(textField_26);
		
		textField_27 = new JTextField();
		textField_27.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_26.requestFocus();
		}
			
		}
		});
		textField_27.setColumns(10);
		textField_27.setBounds(382, 112, 170, 20);
		panel_15.add(textField_27);
		
		textField_29 = new JTextField();
		textField_29.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_30.requestFocus();
		}
			
		}
	
		});
		textField_29.setColumns(10);
		textField_29.setBounds(382, 201, 170, 20);
		panel_15.add(textField_29);
		
		textField_28 = new JTextField();
		textField_28.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_29.requestFocus();
		}
			
		}
			
		});
		textField_28.setBounds(382, 174, 170, 20);
		panel_15.add(textField_28);
		textField_28.setColumns(10);
		
		JPanel panel_16 = new JPanel();
		panel_16.setBackground(Color.WHITE);
		panel_16.setBorder(new TitledBorder(null, "Other", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panel_16.setBounds(10, 468, 562, 223);
		panel_10.add(panel_16);
		panel_16.setLayout(null);
		
		JLabel lblClubDues = new JLabel("Club Due");
		lblClubDues.setBounds(25, 5, 91, 31);
		panel_16.add(lblClubDues);
		lblClubDues.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblMssnDue = new JLabel("Mssn Due");
		lblMssnDue.setBounds(25, 34, 91, 31);
		panel_16.add(lblMssnDue);
		lblMssnDue.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFcfDues = new JLabel("FCF DUES");
		lblFcfDues.setBounds(25, 65, 91, 31);
		panel_16.add(lblFcfDues);
		lblFcfDues.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblMercelinous = new JLabel("Mercelinous");
		lblMercelinous.setBounds(25, 88, 91, 31);
		panel_16.add(lblMercelinous);
		lblMercelinous.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblPtaLevy = new JLabel("PTA Levy");
		lblPtaLevy.setBounds(25, 119, 91, 31);
		panel_16.add(lblPtaLevy);
		lblPtaLevy.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		textField_30 = new JTextField();
		textField_30.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_31.requestFocus();
		}
			
		}
			
		});
		textField_30.setBounds(382, 16, 170, 20);
		panel_16.add(textField_30);
		textField_30.setColumns(10);
		
		textField_31 = new JTextField();
		textField_31.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_32.requestFocus();
		}
		
		
			}
		});
		textField_31.setColumns(10);
		textField_31.setBounds(382, 40, 170, 20);
		panel_16.add(textField_31);
		
		textField_32 = new JTextField();
		textField_32.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_33.requestFocus();
		}
			
		}
			
		});
		textField_32.setColumns(10);
		textField_32.setBounds(382, 71, 170, 20);
		panel_16.add(textField_32);
		
		textField_33 = new JTextField();
		textField_33.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_34.requestFocus();
		}
			
		
			}
		});
		textField_33.setColumns(10);
		textField_33.setBounds(382, 94, 170, 20);
		panel_16.add(textField_33);
		
		textField_34 = new JTextField();
		textField_34.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_20.requestFocus();
		}
			
	
			}
		});
		textField_34.setColumns(10);
		textField_34.setBounds(382, 125, 170, 20);
		panel_16.add(textField_34);
		
		JPanel panel_17 = new JPanel();
		panel_17.setBackground(Color.WHITE);
		panel_17.setBorder(new TitledBorder(null, "Payment Summary", TitledBorder.CENTER, TitledBorder.TOP, null, Color.BLACK));
		panel_17.setBounds(582, 509, 540, 182);
		panel_10.add(panel_17);
		panel_17.setLayout(null);
		
		JPanel panel_20 = new JPanel();
		panel_20.setBackground(Color.WHITE);
		panel_20.setBorder(new TitledBorder(null, "", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panel_20.setBounds(10, 25, 153, 146);
		panel_17.add(panel_20);
		panel_20.setLayout(null);
		
		JLabel lblExpectedFee = new JLabel("Expected Fee");
		lblExpectedFee.setBounds(10, 50, 110, 14);
		panel_20.add(lblExpectedFee);
		lblExpectedFee.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblBalance = new JLabel("Balance");
		lblBalance.setBounds(10, 84, 110, 14);
		panel_20.add(lblBalance);
		lblBalance.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblTotalFeePaid = new JLabel("Total Fee Paid");
		lblTotalFeePaid.setBounds(10, 15, 110, 14);
		panel_20.add(lblTotalFeePaid);
		lblTotalFeePaid.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JPanel panel_19 = new JPanel();
		panel_19.setBackground(Color.WHITE);
		panel_19.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_19.setBounds(216, 25, 176, 104);
		panel_17.add(panel_19);
		panel_19.setLayout(null);
		
		totals = new JTextField();
		totals.setEditable(false);
		totals.setBounds(10, 11, 156, 20);
		panel_19.add(totals);
		totals.setColumns(10);
		
		textField_36 = new JTextField();
		textField_36.setEditable(false);
		textField_36.setColumns(10);
		textField_36.setBounds(10, 46, 156, 20);
		panel_19.add(textField_36);
		
		textField_37 = new JTextField();
		textField_37.setEditable(false);
		textField_37.setColumns(10);
		textField_37.setBounds(10, 77, 156, 20);
		panel_19.add(textField_37);
		
		JPanel panel_32 = new JPanel();
		panel_32.setBackground(Color.WHITE);
		panel_32.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_32.setBounds(396, 12, 134, 146);
		panel_17.add(panel_32);
		panel_32.setLayout(null);
		
		btnNewButton_2 = new JButton("Total");
		btnNewButton_2.setBounds(6, 11, 118, 23);
		panel_32.add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("Preview");
		btnNewButton_2_1.setBounds(6, 63, 118, 23);
		panel_32.add(btnNewButton_2_1);
		
		JButton btnNewButton_2_2 = new JButton("Save");
		btnNewButton_2_2.setBounds(6, 37, 118, 23);
		panel_32.add(btnNewButton_2_2);
		
		JButton btnNewButton_2_1_1 = new JButton("clear");
		btnNewButton_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField_20.setText(null);
				textField_21.setText(null);
				textField_22.setText(null);
				textField_23.setText(null);
				textField_24.setText(null);
				textField_25.setText(null);
				textField_26.setText(null);
				textField_27.setText(null);
				textField_28.setText(null);
				textField_29.setText(null);
				textField_30.setText(null);
				textField_31.setText(null);
				textField_32.setText(null);
				textField_33.setText(null);
				textField_34.setText(null);
				comboBox_7.setSelectedItem(null);
				comboBox_8.setSelectedItem(null);
				dateChooser_2.setCalendar(null);
				textArea_3.setText(null);
				
			}
		});
		btnNewButton_2_1_1.setBounds(6, 119, 118, 23);
		panel_32.add(btnNewButton_2_1_1);
		
		JButton btnNewButton_2_1_1_1 = new JButton("Print");
		btnNewButton_2_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					textArea_3.print();
				} catch (PrinterException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnNewButton_2_1_1_1.setBounds(6, 90, 118, 23);
		panel_32.add(btnNewButton_2_1_1_1);
		btnNewButton_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(validateFieldthree()) {
				String sql="INSERT INTO npaymentdb(FirstName,LastName,MiddleName,Typeofpayment,Dateofpayment,Term,Tuition,Developmentlevy,Uniform,Sport,Form,Notebook,Cardigan,Club,Mssn,Fcf,Merce,Pta,Total,Expectedfee,Balance)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				try {
					pst=connection.prepareStatement(sql);
					pst.setString(1, textField_20.getText());
					pst.setString(2, textField_21.getText());
					pst.setString(3, textField_22.getText());
					String value=comboBox_7.getSelectedItem().toString();
					pst.setString(4, value);
					pst.setString(5, ((JTextField)dateChooser_2.getDateEditor().getUiComponent()).getText());
					String values=comboBox_8.getSelectedItem().toString();
					pst.setString(6, values);
					pst.setString(7, textField_23.getText());
					pst.setString(8, textField_24.getText());
					pst.setString(9, textField_25.getText());
					pst.setString(10, textField_27.getText());
					pst.setString(11, textField_26.getText());
					pst.setString(12, textField_28.getText());
					pst.setString(13, textField_29.getText());
					pst.setString(14, textField_30.getText());
					pst.setString(15, textField_31.getText());
					pst.setString(16, textField_32.getText());
					pst.setString(17, textField_33.getText());
					pst.setString(18, textField_34.getText());
					pst.setString(19, totals.getText());
					pst.setString(20, textField_36.getText());
					pst.setString(21, textField_37.getText());
					
					pst.execute();
					JOptionPane.showMessageDialog(null, "inserted");
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e);
				}
			}
		}});
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String name=textField_20.getText();
				String lastname=textField_21.getText();
				String middlename=textField_22.getText();
				String man=(String) comboBox_7.getSelectedItem();
				String date=((JTextField)dateChooser_2.getDateEditor().getUiComponent()).getText();
				String mans=(String) comboBox_8.getSelectedItem();
				double tuition=Double.parseDouble(textField_23.getText());
				double development=Double.parseDouble(textField_24.getText());
				double uniform=Double.parseDouble(textField_25.getText());
				double sport=Double.parseDouble(textField_27.getText());
				double form=Double.parseDouble(textField_26.getText());
				double note=Double.parseDouble(textField_28.getText());
				double card=Double.parseDouble(textField_29.getText());
				double club=Double.parseDouble(textField_30.getText());
				double mssn=Double.parseDouble(textField_31.getText());
				double fcf=Double.parseDouble(textField_32.getText());
				double merce=Double.parseDouble(textField_33.getText());
				double pta=Double.parseDouble(textField_34.getText());
				float expectedfee=Float.parseFloat(textField_36.getText());
				float balancefee=Float.parseFloat(textField_37.getText());
				float totalfee=Float.parseFloat(totals.getText());
				
				
				
				textArea_3.append("\t\tMY SCHOOL MANAGEMENT SYSTEM"+
				"\n\t\tNEW STUDENT RECEIPT"+
				"\nFirstName\t\t\t"+name+ "\nLastName\t\t\t"+lastname+"\nMiddleName\t\t\t"+middlename+"\nType Of Payment\t\t"+man+
				"\nDate Of Payment\t\t"+date+"\nTerm\t\t\t"+mans
				+"\nTuition\t\t\t"+"₦ "+tuition+"\nDevelopment Fee\t\t"+"₦ "+development+
				"\nUniform\t\t\t"+"₦ "+uniform+"\nSport\t\t\t"+"₦ "+sport+"\nForm\t\t\t"+"₦ "+form+"\nNoteBook\t\t\t"+"₦ "+note
				+"\nCardigan\t\t\t"+"₦ "+card+"\nClub Dues\t\t\t"+"₦ "+club+"\nMssn Dues\t\t\t"+"₦ "+mssn+
				"\nFcf Dues\t\t\t"+"₦ "+fcf+"\nMercelinous\t\t\t"+"₦ "+merce+"\nPta levy\t\t\t"+"₦ "+pta+"\n---------------------------------------------------------------------------------------"+"\nExpected fee\t\t\t"+"₦ "+expectedfee+"\nBalance\t\t\t"+"₦ "
				+balancefee+"\nTotal Fee Paid\t\t\t"+"₦ "+totalfee
			
				
				);
			}
		});
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if(validateFieldfour()) {
				String tuitiontext=textField_23.getText();
				float tuition=Float.parseFloat(tuitiontext);
				String developmenttext=textField_24.getText();
				float development=Float.parseFloat(developmenttext);
				String uniformtext=textField_25.getText();
				float uniform=Float.parseFloat(uniformtext);
				String formtext=textField_26.getText();
				float form=Float.parseFloat(formtext);
				String sporttext=textField_27.getText();
				float sport=Float.parseFloat(sporttext);
				String notetext=textField_28.getText();
				float note=Float.parseFloat(notetext);
				String cardigantext=textField_29.getText();
				float cardigan=Float.parseFloat(cardigantext);
				String clubtext=textField_30.getText();
				float club=Float.parseFloat(clubtext);
				String mssntext=textField_31.getText();
				float mssn=Float.parseFloat(mssntext);
				String fcftext=textField_32.getText();
				float fcf=Float.parseFloat(fcftext);
				String mercetext=textField_33.getText();
				float merce=Float.parseFloat(mercetext);
				String ptatext=textField_34.getText();
				float pta=Float.parseFloat(ptatext);
				float total=tuition+development+uniform+form+sport+note+cardigan+club+mssn+fcf+merce+pta;
				totals.setText(""+total);
				textField_36.setText(""+35000);
				float balance=35000-total;
				textField_37.setText(""+balance);
			
				}
			}
		});
		
		JPanel panel_18 = new JPanel();
		panel_18.setBackground(Color.WHITE);
		panel_18.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Receipt", TitledBorder.CENTER, TitledBorder.TOP, null, Color.BLACK));
		panel_18.setBounds(582, 11, 540, 487);
		panel_10.add(panel_18);
		panel_18.setLayout(null);
		
		textArea_3 = new JTextArea();
		textArea_3.setEditable(false);
		textArea_3.setBounds(10, 21, 520, 453);
		panel_18.add(textArea_3);
		
		JPanel panel_11 = new JPanel();
		panel_11.setBackground(Color.WHITE);
		tabbedPane_2.addTab("Returning Student Payment", null, panel_11, null);
		panel_11.setLayout(null);
		
		JPanel panel_23 = new JPanel();
		panel_23.setBackground(Color.WHITE);
		panel_23.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Biodata", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_23.setBounds(6, 16, 449, 237);
		panel_11.add(panel_23);
		panel_23.setLayout(null);
		
		JLabel lblFirstname_2_3 = new JLabel("FirstName");
		lblFirstname_2_3.setBounds(6, 16, 136, 31);
		panel_23.add(lblFirstname_2_3);
		lblFirstname_2_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_3_1 = new JLabel("MiddleName");
		lblFirstname_2_3_1.setBounds(6, 58, 136, 31);
		panel_23.add(lblFirstname_2_3_1);
		lblFirstname_2_3_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_3_2 = new JLabel("LastName");
		lblFirstname_2_3_2.setBounds(6, 100, 136, 31);
		panel_23.add(lblFirstname_2_3_2);
		lblFirstname_2_3_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		textField_71 = new JTextField();
		textField_71.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_72.requestFocus();
		}
			
		
			}
		});
		textField_71.setBounds(198, 22, 241, 20);
		panel_23.add(textField_71);
		textField_71.setColumns(10);
		
		textField_72 = new JTextField();
		textField_72.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_73.requestFocus();
		}
			
		
			}
		
			
		});
		textField_72.setBounds(198, 64, 241, 20);
		panel_23.add(textField_72);
		textField_72.setColumns(10);
		
		textField_73 = new JTextField();
		textField_73.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_74.requestFocus();
		}
			
		
			
			}
		});
		textField_73.setBounds(198, 106, 241, 20);
		panel_23.add(textField_73);
		textField_73.setColumns(10);
		
		JLabel lblFirstname_2_3_2_1 = new JLabel("Date Of Payment");
		lblFirstname_2_3_2_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFirstname_2_3_2_1.setBounds(6, 145, 136, 31);
		panel_23.add(lblFirstname_2_3_2_1);
		
		JLabel lblFirstname_2_3_2_1_1 = new JLabel("Type Of Payment");
		lblFirstname_2_3_2_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFirstname_2_3_2_1_1.setBounds(6, 187, 136, 31);
		panel_23.add(lblFirstname_2_3_2_1_1);
		
		JDateChooser dateChooser_4 = new JDateChooser();
		dateChooser_4.setBounds(198, 156, 241, 20);
		panel_23.add(dateChooser_4);
		
		JComboBox comboBox_10 = new JComboBox();
		comboBox_10.setModel(new DefaultComboBoxModel(new String[] {"Select", "Half Payment", "Full Payment"}));
		comboBox_10.setBounds(198, 193, 241, 20);
		panel_23.add(comboBox_10);
		
		JPanel panel_24 = new JPanel();
		panel_24.setBackground(Color.WHITE);
		panel_24.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Returning Student Payment", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_24.setBounds(6, 264, 449, 182);
		panel_11.add(panel_24);
		panel_24.setLayout(null);
		
		JLabel lblFirstname_2_3_3 = new JLabel("Tuition");
		lblFirstname_2_3_3.setBounds(10, 16, 136, 31);
		panel_24.add(lblFirstname_2_3_3);
		lblFirstname_2_3_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_3_3_1 = new JLabel("Development fee");
		lblFirstname_2_3_3_1.setBounds(6, 58, 136, 31);
		panel_24.add(lblFirstname_2_3_3_1);
		lblFirstname_2_3_3_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		textField_74 = new JTextField();
		textField_74.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_75.requestFocus();
		}
			
		
			
			}
		});
		textField_74.setBounds(205, 22, 234, 20);
		panel_24.add(textField_74);
		textField_74.setColumns(10);
		
		textField_75 = new JTextField();
		textField_75.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_76.requestFocus();
		}
			
		
			}
		});
		textField_75.setBounds(205, 64, 234, 20);
		panel_24.add(textField_75);
		textField_75.setColumns(10);
		
		JLabel lblFirstname_2_3_3_1_1 = new JLabel("Lesson Fee");
		lblFirstname_2_3_3_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFirstname_2_3_3_1_1.setBounds(6, 100, 136, 31);
		panel_24.add(lblFirstname_2_3_3_1_1);
		
		JLabel lblFirstname_2_3_3_1_1_1 = new JLabel("Note Book");
		lblFirstname_2_3_3_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFirstname_2_3_3_1_1_1.setBounds(6, 142, 136, 31);
		panel_24.add(lblFirstname_2_3_3_1_1_1);
		
		textField_76 = new JTextField();
		textField_76.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_77.requestFocus();
		}
			
		
			}
			
		});
		textField_76.setColumns(10);
		textField_76.setBounds(205, 106, 234, 20);
		panel_24.add(textField_76);
		
		textField_77 = new JTextField();
		textField_77.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_78.requestFocus();
		}
			
		
			
			}
		});
		textField_77.setColumns(10);
		textField_77.setBounds(205, 148, 234, 20);
		panel_24.add(textField_77);
		
		JPanel panel_25 = new JPanel();
		panel_25.setBackground(Color.WHITE);
		panel_25.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Others", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_25.setBounds(7, 457, 448, 234);
		panel_11.add(panel_25);
		panel_25.setLayout(null);
		
		JLabel lblFirstname_2_3_3_1_1_1_1 = new JLabel("Club Dues");
		lblFirstname_2_3_3_1_1_1_1.setBounds(10, 16, 136, 31);
		panel_25.add(lblFirstname_2_3_3_1_1_1_1);
		lblFirstname_2_3_3_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_3_3_1_1_1_1_1 = new JLabel("Mssn Dues");
		lblFirstname_2_3_3_1_1_1_1_1.setBounds(10, 69, 136, 31);
		panel_25.add(lblFirstname_2_3_3_1_1_1_1_1);
		lblFirstname_2_3_3_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_3_3_1_1_1_1_1_1 = new JLabel("Fcf Dues");
		lblFirstname_2_3_3_1_1_1_1_1_1.setBounds(10, 111, 136, 31);
		panel_25.add(lblFirstname_2_3_3_1_1_1_1_1_1);
		lblFirstname_2_3_3_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_3_3_1_1_1_1_1_1_1 = new JLabel("Mercelinous");
		lblFirstname_2_3_3_1_1_1_1_1_1_1.setBounds(10, 153, 136, 31);
		panel_25.add(lblFirstname_2_3_3_1_1_1_1_1_1_1);
		lblFirstname_2_3_3_1_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_3_3_1_1_1_1_1_1_2 = new JLabel("Pta Levy");
		lblFirstname_2_3_3_1_1_1_1_1_1_2.setBounds(10, 195, 136, 31);
		panel_25.add(lblFirstname_2_3_3_1_1_1_1_1_1_2);
		lblFirstname_2_3_3_1_1_1_1_1_1_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		textField_78 = new JTextField();
		textField_78.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_79.requestFocus();
		}
			
		
			}
			
		});
		textField_78.setBounds(210, 22, 228, 20);
		panel_25.add(textField_78);
		textField_78.setColumns(10);
		
		textField_79 = new JTextField();
		textField_79.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_80.requestFocus();
		}
			
		
			}
		
		});
		textField_79.setBounds(210, 75, 228, 20);
		panel_25.add(textField_79);
		textField_79.setColumns(10);
		
		textField_80 = new JTextField();
		textField_80.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_81.requestFocus();
		}
			
		
			}

		});
		textField_80.setBounds(210, 117, 228, 20);
		panel_25.add(textField_80);
		textField_80.setColumns(10);
		
		textField_81 = new JTextField();
		textField_81.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_82.requestFocus();
		}
			
		
			
			}
		});
		textField_81.setBounds(210, 159, 228, 20);
		panel_25.add(textField_81);
		textField_81.setColumns(10);
		
		textField_82 = new JTextField();
		textField_82.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_71.requestFocus();
		}
			
		
			
			}
		});
		textField_82.setBounds(210, 201, 228, 20);
		panel_25.add(textField_82);
		textField_82.setColumns(10);
		
		JPanel panel_26 = new JPanel();
		panel_26.setBackground(Color.WHITE);
		panel_26.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Receipt", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_26.setBounds(459, 11, 663, 521);
		panel_11.add(panel_26);
		panel_26.setLayout(null);
		
		JScrollPane scrollPane_8 = new JScrollPane();
		scrollPane_8.setBounds(10, 18, 643, 492);
		panel_26.add(scrollPane_8);
		
		JTextArea textArea_5 = new JTextArea();
		scrollPane_8.setViewportView(textArea_5);
		textArea_5.setEditable(false);
		textArea_5.setLineWrap(true);
		
		JPanel panel_27 = new JPanel();
		panel_27.setBackground(Color.WHITE);
		panel_27.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Payment Sumary", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_27.setBounds(459, 542, 470, 149);
		panel_11.add(panel_27);
		panel_27.setLayout(null);
		
		JPanel panel_28 = new JPanel();
		panel_28.setBackground(Color.WHITE);
		panel_28.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_28.setBounds(0, 0, 129, 138);
		panel_27.add(panel_28);
		panel_28.setLayout(null);
		
		JLabel lblFirstname_2_3_3_1_1_1_1_1_1_1_1 = new JLabel("Total Fee Paid");
		lblFirstname_2_3_3_1_1_1_1_1_1_1_1.setBounds(6, 16, 136, 31);
		panel_28.add(lblFirstname_2_3_3_1_1_1_1_1_1_1_1);
		lblFirstname_2_3_3_1_1_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_3_3_1_1_1_1_1_1_1_2 = new JLabel("Expected Fee");
		lblFirstname_2_3_3_1_1_1_1_1_1_1_2.setBounds(6, 58, 136, 31);
		panel_28.add(lblFirstname_2_3_3_1_1_1_1_1_1_1_2);
		lblFirstname_2_3_3_1_1_1_1_1_1_1_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JLabel lblFirstname_2_3_3_1_1_1_1_1_1_1_3 = new JLabel("Balance");
		lblFirstname_2_3_3_1_1_1_1_1_1_1_3.setBounds(6, 100, 136, 31);
		panel_28.add(lblFirstname_2_3_3_1_1_1_1_1_1_1_3);
		lblFirstname_2_3_3_1_1_1_1_1_1_1_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		
		JPanel panel_29 = new JPanel();
		panel_29.setBackground(Color.WHITE);
		panel_29.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_29.setBounds(202, 16, 185, 122);
		panel_27.add(panel_29);
		panel_29.setLayout(null);
		
		textField_83 = new JTextField();
		textField_83.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_83.setEditable(false);
		textField_83.setBounds(6, 16, 173, 20);
		panel_29.add(textField_83);
		textField_83.setColumns(10);
		
		textField_84 = new JTextField();
		textField_84.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_84.setEditable(false);
		textField_84.setBounds(6, 58, 173, 20);
		panel_29.add(textField_84);
		textField_84.setColumns(10);
		
		textField_85 = new JTextField();
		textField_85.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_85.setEditable(false);
		textField_85.setBounds(6, 100, 173, 20);
		panel_29.add(textField_85);
		textField_85.setColumns(10);
		
		JPanel panel_30 = new JPanel();
		panel_30.setBackground(Color.WHITE);
		panel_30.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_30.setBounds(929, 530, 193, 161);
		panel_11.add(panel_30);
		panel_30.setLayout(null);
		
		JButton btnNewButton_5 = new JButton("Compute");
		btnNewButton_5.setBounds(6, 31, 177, 23);
		panel_30.add(btnNewButton_5);
		
		JButton btnNewButton_5_1 = new JButton("Preview");
		btnNewButton_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			String fname=textField_71.getText();
			String mname=textField_72.getText();
			String lname=textField_73.getText();
			String date=((JTextField)dateChooser_4.getDateEditor().getUiComponent()).getText();
			String man=(String) comboBox_10.getSelectedItem();
			String tuition=textField_74.getText();
			String development=textField_75.getText();
			String lesson=textField_76.getText();
			String notebook=textField_77.getText();
			String club=textField_78.getText();
			String mssn=textField_79.getText();
			String fcf=textField_80.getText();
			String merce=textField_81.getText();
			String pta=textField_82.getText();
			String total=textField_83.getText();
			String expected=textField_84.getText();
			String balance=textField_85.getText();
				textArea_5.append("=============================MYSCHOOL MANAGEMENT SOFTWARE============================="+"\n\t\t                     RETURNING STUDENT RECEIPT"+"\n\tName\t\t "+fname+" "+mname+" "+lname+"\n\tDate Of Payment\t\t"+date+
						"\n\tType Of Payment\t\t"+man+"\n\tTuition\t\t\t"+"₦ "+tuition+"\n\tDevelopment Fee\t\t       "+"₦ "+development+"\n\tLesson Fee\t\t                  "+"₦ "+lesson+"\n\tNote Book\t\t                    "+"₦ "+notebook+"\n\tClub Dues\t\t                      "+"₦ "+club+"\n\tMssn Dues\t\t                     "+"₦ "+mssn+"\n\tFcf Dues\t\t                         "+"₦ "+fcf+"\n\tMercelinous\t\t                     "+"₦ "+merce+"\n\tPtaLevy\t\t                          "+"₦ "+pta+"\n\n\t\t\t PAYMENT SURMARY"+"\n\tTotal Fee Paid\t\t                       "+"₦ "+total+"\n\tExpected Fee\t\t                          "+"₦ "+expected+"\n\tBalance\t\t                                      "+"₦ "+balance)
				;} 
		});
		btnNewButton_5_1.setBounds(6, 55, 177, 23);
		panel_30.add(btnNewButton_5_1);
		
		JButton btnNewButton_5_2 = new JButton("Print");
		btnNewButton_5_2.setBounds(6, 102, 177, 23);
		panel_30.add(btnNewButton_5_2);
		
		JButton btnNewButton_5_3 = new JButton("Clear");
		btnNewButton_5_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField_74.setText(null);
				textField_75.setText(null);
				textField_76.setText(null);
				textField_77.setText(null);
				textField_78.setText(null);
				textField_79.setText(null);
				textField_80.setText(null);
				textField_81.setText(null);
				textField_82.setText(null);
				textField_83.setText(null);
				textField_84.setText(null);
				textField_85.setText(null);
				textField_71.setText(null);
				textField_72.setText(null);
				textField_73.setText(null);
				dateChooser_4.setCalendar(null);
				comboBox_10.setSelectedItem(null);
				textArea_5.setText(null);
				
			}
		});
		btnNewButton_5_3.setBounds(6, 126, 177, 23);
		panel_30.add(btnNewButton_5_3);
		
		JButton btnNewButton_5_1_1 = new JButton("Save");
		btnNewButton_5_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(validateFieldseven()) {
				String sql="INSERT INTO returndb(FirstName,LastName,MiddleName,DateOfPayment,TypeOfPayment,Tuition,DevelopmentFee,LessonFee,NoteBook,ClubDues,MssnDues,FcfDues,Mercelinous,Ptalevy,TotalFee,ExpectedFee,Balance)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				try {
					pst=connection.prepareStatement(sql);
					pst.setString(1, textField_71.getText());
					pst.setString(2, textField_72.getText());
					pst.setString(3, textField_73.getText());
					pst.setString(4, ((JTextField)dateChooser_4.getDateEditor().getUiComponent()).getText());
					String values=comboBox_10.getSelectedItem().toString();
					pst.setString(5, values);
					pst.setString(6, textField_74.getText());
					pst.setString(7, textField_75.getText());
					pst.setString(8, textField_76.getText());
					pst.setString(9, textField_77.getText());
					pst.setString(10, textField_78.getText());
					pst.setString(11, textField_79.getText());
					pst.setString(12, textField_80.getText());
					pst.setString(13, textField_81.getText());
					pst.setString(14, textField_82.getText());
					pst.setString(15, textField_83.getText());
					pst.setString(16, textField_84.getText());
					pst.setString(17, textField_85.getText());
					
					pst.execute();
					JOptionPane.showMessageDialog(null, "inserted");
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e);
				}
			}
			}
		});
		btnNewButton_5_1_1.setBounds(6, 78, 177, 23);
		panel_30.add(btnNewButton_5_1_1);
		
		JPanel panel_35 = new JPanel();
		panel_35.setBackground(Color.WHITE);
		tabbedPane_2.addTab("Subject Registration", null, panel_35, null);
		panel_35.setLayout(null);
		
		JLabel lblSubjectRegistration = new JLabel("Subject Registration ");
		lblSubjectRegistration.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblSubjectRegistration.setBounds(741, 0, 246, 49);
		panel_35.add(lblSubjectRegistration);
		
		JLabel lblFirstname_3 = new JLabel("FirstName");
		lblFirstname_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblFirstname_3.setBounds(10, 25, 85, 37);
		panel_35.add(lblFirstname_3);
		
		textField_88 = new JTextField();
		textField_88.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_89.requestFocus();
		}
			
		
			
			}
		});
		textField_88.setBounds(269, 35, 169, 20);
		panel_35.add(textField_88);
		textField_88.setColumns(10);
		
		JLabel lblFirstname_3_1 = new JLabel("LastName");
		lblFirstname_3_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblFirstname_3_1.setBounds(10, 88, 85, 37);
		panel_35.add(lblFirstname_3_1);
		
		JLabel lblFirstname_3_2 = new JLabel("MiddleName");
		lblFirstname_3_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblFirstname_3_2.setBounds(10, 57, 117, 37);
		panel_35.add(lblFirstname_3_2);
		
		JLabel lblFirstname_3_2_1 = new JLabel("Term");
		lblFirstname_3_2_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblFirstname_3_2_1.setBounds(10, 121, 117, 37);
		panel_35.add(lblFirstname_3_2_1);
		
		textField_89 = new JTextField();
		textField_89.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_90.requestFocus();
		}
			
		
			}
			
		});
		textField_89.setColumns(10);
		textField_89.setBounds(269, 66, 169, 20);
		panel_35.add(textField_89);
		
		textField_90 = new JTextField();
		textField_90.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_88.requestFocus();
		}
			
		
			
			}
		});
		textField_90.setColumns(10);
		textField_90.setBounds(269, 98, 169, 20);
		panel_35.add(textField_90);
		
		JComboBox comboBox_11 = new JComboBox();
		comboBox_11.setForeground(Color.WHITE);
		comboBox_11.setModel(new DefaultComboBoxModel(new String[] {"Select Term", "FirstTerm", "SecondTerm", "ThirdTerm"}));
		comboBox_11.setBounds(269, 131, 166, 20);
		panel_35.add(comboBox_11);
		
		JLabel lblSelectSubject = new JLabel("Select Subject");
		lblSelectSubject.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblSelectSubject.setBounds(223, 204, 95, 25);
		panel_35.add(lblSelectSubject);
		
		JComboBox comboBox_12 = new JComboBox();
		comboBox_12.setForeground(Color.WHITE);
		comboBox_12.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science", "Nil"}));
		comboBox_12.setBounds(200, 259, 238, 20);
		panel_35.add(comboBox_12);
		
		JComboBox comboBox_12_1 = new JComboBox();
		comboBox_12_1.setForeground(Color.WHITE);
		comboBox_12_1.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science", "Nil"}));
		comboBox_12_1.setBounds(200, 290, 238, 20);
		panel_35.add(comboBox_12_1);
		
		JComboBox comboBox_12_2 = new JComboBox();
		comboBox_12_2.setForeground(Color.WHITE);
		comboBox_12_2.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science", "Nil"}));
		comboBox_12_2.setBounds(200, 321, 238, 20);
		panel_35.add(comboBox_12_2);
		
		JComboBox comboBox_12_3 = new JComboBox();
		comboBox_12_3.setForeground(Color.WHITE);
		comboBox_12_3.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science", "Nil"}));
		comboBox_12_3.setBounds(200, 352, 238, 20);
		panel_35.add(comboBox_12_3);
		
		JComboBox comboBox_12_4 = new JComboBox();
		comboBox_12_4.setForeground(Color.WHITE);
		comboBox_12_4.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science", "Nil"}));
		comboBox_12_4.setBounds(200, 383, 238, 20);
		panel_35.add(comboBox_12_4);
		
		JComboBox comboBox_12_5 = new JComboBox();
		comboBox_12_5.setForeground(Color.WHITE);
		comboBox_12_5.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science", "Nil"}));
		comboBox_12_5.setBounds(200, 414, 238, 20);
		panel_35.add(comboBox_12_5);
		
		JComboBox comboBox_12_6 = new JComboBox();
		comboBox_12_6.setForeground(Color.WHITE);
		comboBox_12_6.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science", "Nil"}));
		comboBox_12_6.setBounds(200, 445, 238, 20);
		panel_35.add(comboBox_12_6);
		
		JComboBox comboBox_12_7 = new JComboBox();
		comboBox_12_7.setForeground(Color.WHITE);
		comboBox_12_7.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science", "Nil"}));
		comboBox_12_7.setBounds(200, 476, 238, 20);
		panel_35.add(comboBox_12_7);
		
		JComboBox comboBox_12_8 = new JComboBox();
		comboBox_12_8.setForeground(Color.WHITE);
		comboBox_12_8.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science"}));
		comboBox_12_8.setBounds(200, 507, 238, 20);
		panel_35.add(comboBox_12_8);
		
		JComboBox comboBox_12_9 = new JComboBox();
		comboBox_12_9.setForeground(Color.WHITE);
		comboBox_12_9.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science"}));
		comboBox_12_9.setBounds(200, 538, 238, 20);
		panel_35.add(comboBox_12_9);
		
		JComboBox comboBox_12_10 = new JComboBox();
		comboBox_12_10.setForeground(Color.WHITE);
		comboBox_12_10.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science"}));
		comboBox_12_10.setBounds(200, 569, 238, 20);
		panel_35.add(comboBox_12_10);
		
		JComboBox comboBox_12_11 = new JComboBox();
		comboBox_12_11.setForeground(Color.WHITE);
		comboBox_12_11.setModel(new DefaultComboBoxModel(new String[] {"Select Subject", "Mathematics", "English", "Biology", "Chemistry", "Physics", "Government", "Financial Accounting", "Commerce", "Geography", "Literature In English", "computer Science", "Agricultural Science"}));
		comboBox_12_11.setBounds(200, 600, 238, 20);
		panel_35.add(comboBox_12_11);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setBounds(587, 34, 472, 2);
		panel_35.add(separator_4);
		
		JPanel panel_36 = new JPanel();
		panel_36.setBackground(Color.WHITE);
		panel_36.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_36.setBounds(486, 45, 622, 467);
		panel_35.add(panel_36);
		panel_36.setLayout(null);
		
		JScrollPane scrollPane_11 = new JScrollPane();
		scrollPane_11.setBounds(6, 16, 606, 444);
		panel_36.add(scrollPane_11);
		
		JTextArea textArea_6 = new JTextArea();
		textArea_6.setEditable(false);
		textArea_6.setLineWrap(true);
		scrollPane_11.setViewportView(textArea_6);
		
		JPanel panel_37 = new JPanel();
		panel_37.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_37.setBounds(486, 530, 196, 123);
		panel_35.add(panel_37);
		panel_37.setLayout(null);
		
		JLabel lblFirstname_3_2_1_1 = new JLabel("Total Subject Taken");
		lblFirstname_3_2_1_1.setBounds(6, 11, 147, 37);
		panel_37.add(lblFirstname_3_2_1_1);
		lblFirstname_3_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblFirstname_3_2_1_1_1 = new JLabel("Mark Obtainable/Subject");
		lblFirstname_3_2_1_1_1.setBounds(6, 44, 184, 37);
		panel_37.add(lblFirstname_3_2_1_1_1);
		lblFirstname_3_2_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblFirstname_3_2_1_1_1_1 = new JLabel("Mark Obtainable");
		lblFirstname_3_2_1_1_1_1.setBounds(6, 84, 147, 37);
		panel_37.add(lblFirstname_3_2_1_1_1_1);
		lblFirstname_3_2_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		JLabel lblSn = new JLabel("S/N");
		lblSn.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblSn.setBounds(10, 204, 95, 25);
		panel_35.add(lblSn);
		
		JLabel label_1 = new JLabel("1.");
		label_1.setBounds(10, 261, 46, 17);
		panel_35.add(label_1);
		
		JLabel label_1_1 = new JLabel("2.");
		label_1_1.setBounds(10, 289, 46, 17);
		panel_35.add(label_1_1);
		
		JLabel label_1_2 = new JLabel("3.");
		label_1_2.setBounds(10, 323, 46, 17);
		panel_35.add(label_1_2);
		
		JLabel label_1_3 = new JLabel("4.");
		label_1_3.setBounds(10, 354, 46, 17);
		panel_35.add(label_1_3);
		
		JLabel label_1_4 = new JLabel("5.");
		label_1_4.setBounds(10, 385, 46, 17);
		panel_35.add(label_1_4);
		
		JLabel label_1_5 = new JLabel("6.");
		label_1_5.setBounds(10, 416, 46, 17);
		panel_35.add(label_1_5);
		
		JLabel label_1_6 = new JLabel("7.");
		label_1_6.setBounds(10, 447, 46, 17);
		panel_35.add(label_1_6);
		
		JLabel label_1_7 = new JLabel("8.");
		label_1_7.setBounds(10, 478, 46, 17);
		panel_35.add(label_1_7);
		
		JLabel label_1_8 = new JLabel("9.");
		label_1_8.setBounds(10, 509, 46, 17);
		panel_35.add(label_1_8);
		
		JLabel label_1_9 = new JLabel("10.");
		label_1_9.setBounds(10, 540, 46, 17);
		panel_35.add(label_1_9);
		
		JLabel label_1_10 = new JLabel("11.");
		label_1_10.setBounds(10, 571, 46, 17);
		panel_35.add(label_1_10);
		
		JLabel label_1_11 = new JLabel("12.");
		label_1_11.setBounds(10, 602, 46, 17);
		panel_35.add(label_1_11);
		
		JSeparator separator_5 = new JSeparator();
		separator_5.setBounds(4, 229, 470, 6);
		panel_35.add(separator_5);
		
		JSeparator separator_6 = new JSeparator();
		separator_6.setOrientation(SwingConstants.VERTICAL);
		separator_6.setBounds(34, 193, 10, 439);
		panel_35.add(separator_6);
		
		JSeparator separator_5_1 = new JSeparator();
		separator_5_1.setBounds(10, 630, 464, 6);
		panel_35.add(separator_5_1);
		
		JSeparator separator_7 = new JSeparator();
		separator_7.setOrientation(SwingConstants.VERTICAL);
		separator_7.setBounds(472, 0, 19, 630);
		panel_35.add(separator_7);
		
		JSeparator separator_5_2 = new JSeparator();
		separator_5_2.setBounds(4, 193, 470, 6);
		panel_35.add(separator_5_2);
		
		JPanel panel_38 = new JPanel();
		panel_38.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_38.setBounds(741, 530, 171, 121);
		panel_35.add(panel_38);
		panel_38.setLayout(null);
		
		textField_91 = new JTextField();
		textField_91.setEditable(false);
		textField_91.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_91.setBounds(6, 16, 159, 20);
		panel_38.add(textField_91);
		textField_91.setColumns(10);
		
		textField_92 = new JTextField();
		textField_92.setEditable(false);
		textField_92.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_92.setBounds(6, 51, 159, 20);
		panel_38.add(textField_92);
		textField_92.setColumns(10);
		
		textField_93 = new JTextField();
		textField_93.setEditable(false);
		textField_93.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_93.setBounds(6, 90, 159, 20);
		panel_38.add(textField_93);
		textField_93.setColumns(10);
		
		JPanel panel_39 = new JPanel();
		panel_39.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_39.setBounds(961, 513, 147, 143);
		panel_35.add(panel_39);
		panel_39.setLayout(null);
		
		JButton btnNewButton_6 = new JButton("Register");
		btnNewButton_6.setBounds(6, 16, 131, 23);
		panel_39.add(btnNewButton_6);
		
		JButton btnNewButton_6_1 = new JButton("Print");
		btnNewButton_6_1.setBounds(6, 47, 131, 23);
		panel_39.add(btnNewButton_6_1);
		
		JButton btnNewButton_6_2 = new JButton("Preview");
		btnNewButton_6_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fname=textField_88.getText();
				String mname=textField_89.getText();
				String lname=textField_90.getText();
				String term=(String) comboBox_11.getSelectedItem();
				String date=((JTextField)dateChooser_5.getDateEditor().getUiComponent()).getText();
				String first =(String) comboBox_12.getSelectedItem();
				String second=(String) comboBox_12_1.getSelectedItem();
				String third=(String) comboBox_12_2.getSelectedItem();
				String fourth=(String) comboBox_12_3.getSelectedItem();
				String fifth=(String) comboBox_12_4.getSelectedItem();
				String sixth=(String) comboBox_12_5.getSelectedItem();
				String seventh=(String) comboBox_12_6.getSelectedItem();
						String eight=(String) comboBox_12_7.getSelectedItem();
								String nineth=(String) comboBox_12_8.getSelectedItem();
								String tenth=(String) comboBox_12_9.getSelectedItem();
								String eleventh=(String) comboBox_12_10.getSelectedItem();
								String twelveth=(String) comboBox_12_11.getSelectedItem();
								String total=textField_91.getText();
								String mark=textField_92.getText();
								String obtain=textField_93.getText();
				
				
				textArea_6.append("\t\tMYSCHOOL MANAGEMENT APPLICATION"+"\n\t\tSUBJECT REGISTRATION"
			+"\n\tNAME:-"+fname+" "+mname+" "+lname+"\n\tTERM:-"+term+"\n\tDate:-"+date+"\n\n\t\tSUBJECT REGISTERED"
			+"\n\n\t1."+first+"\n\t2."+second+"\n\t3."+third+"\n\t4."+fourth+"\n\t5."+fifth+"\n\t6."+sixth+"\n\t7."+seventh+"\n\t8."+eight
			+"\n\t9."+nineth+"\n\t10."+tenth+"\n\t11."+eleventh+"\n\t12."+twelveth+"\n\n\tTOTAL SUBJECT REGISTER:-"+total+"\n\tTOTAL MARK OBTAINABLE/SUBJECT:-"+mark
			+"\n\tTOTAL MARK OBTAINABLE:-"+obtain);
			}
		});
		btnNewButton_6_2.setBounds(6, 79, 131, 23);
		panel_39.add(btnNewButton_6_2);
		
		JButton btnNewButton_6_3 = new JButton("Clear");
		btnNewButton_6_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comboBox_11.setSelectedItem(null);
				comboBox_12.setSelectedItem(null);
				comboBox_12_1.setSelectedItem(null);
				comboBox_12_2.setSelectedItem(null);
				comboBox_12_3.setSelectedItem(null);
				comboBox_12_4.setSelectedItem(null);
				comboBox_12_5.setSelectedItem(null);
				comboBox_12_6.setSelectedItem(null);
				comboBox_12_7.setSelectedItem(null);
				comboBox_12_8.setSelectedItem(null);
				comboBox_12_9.setSelectedItem(null);
				comboBox_12_10.setSelectedItem(null);
				comboBox_12_11.setSelectedItem(null);
				textField_88.setText(null);
				textField_89.setText(null);
				textField_90.setText(null);
				textField_91.setText(null);
				textField_92.setText(null);
				textField_93.setText(null);
				textArea_6.setText(null);
				dateChooser_5.setCalendar(null);
				
			}
		});
		btnNewButton_6_3.setBounds(6, 114, 131, 23);
		panel_39.add(btnNewButton_6_3);
		
		JLabel lblFirstname_3_2_1_2 = new JLabel("Date");
		lblFirstname_3_2_1_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblFirstname_3_2_1_2.setBounds(10, 155, 117, 37);
		panel_35.add(lblFirstname_3_2_1_2);
		
		dateChooser_5 = new JDateChooser();
		dateChooser_5.setBounds(272, 162, 166, 20);
		panel_35.add(dateChooser_5);
		btnNewButton_6_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					textArea_6.print();
				} catch (PrinterException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_91.setText("12");
				textField_92.setText("100");
				textField_93.setText("1200");
			}
		});
		btnNewButton_5_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					textArea_5.print();
				} catch (PrinterException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(validateFieldeight()) {
				String tuitiontext=textField_74.getText();
				float tuition=Float.parseFloat(tuitiontext);
				String dftext=textField_75.getText();
				float df=Float.parseFloat(dftext);
				String lftext=textField_76.getText();
				float lf=Float.parseFloat(lftext);
				String nbtext=textField_77.getText();
				float nb=Float.parseFloat(nbtext);
				String cdtext=textField_78.getText();
				float cd=Float.parseFloat(cdtext);
				String mdtext=textField_79.getText();
				float md=Float.parseFloat(mdtext);
				String fdtext=textField_80.getText();
				float fd=Float.parseFloat(fdtext);
				String mercetext=textField_81.getText();
				float merce=Float.parseFloat(mercetext);
				String ptatext=textField_82.getText();
				float pta=Float.parseFloat(ptatext);
				float total=tuition+df+lf+nb+cd+md+fd+merce+pta;
				textField_83.setText(""+total);
				textField_84.setText(""+25000);
				float balance=25000-total;
						textField_85.setText(""+balance);
			}
			}
		});
		
		panel_4 = new JPanel();
		panel_4.setBackground(Color.WHITE);
		layeredPane.add(panel_4, "name_239365352047552");
		panel_4.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\USER\\workstation\\myproject\\src\\myproject\\images-2.png"));
		lblNewLabel_4.setBounds(177, 49, 131, 149);
		panel_4.add(lblNewLabel_4);
		
		JLabel lblName_1 = new JLabel("FirstName");
		lblName_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblName_1.setBounds(10, 234, 131, 27);
		panel_4.add(lblName_1);
		
		JLabel lblName_1_1 = new JLabel("MiddleName");
		lblName_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblName_1_1.setBounds(10, 259, 131, 27);
		panel_4.add(lblName_1_1);
		
		JLabel lblName_1_2 = new JLabel("LastName");
		lblName_1_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblName_1_2.setBounds(10, 284, 131, 27);
		panel_4.add(lblName_1_2);
		
		JLabel lblName_1_2_1 = new JLabel("Term");
		lblName_1_2_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblName_1_2_1.setBounds(10, 308, 131, 27);
		panel_4.add(lblName_1_2_1);
		
		JLabel lblName_1_2_1_1 = new JLabel("Date Of Resumption");
		lblName_1_2_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblName_1_2_1_1.setBounds(10, 332, 168, 27);
		panel_4.add(lblName_1_2_1_1);
		
		textField_35 = new JTextField();
		textField_35.addKeyListener(new KeyAdapter() {
			@Override
				public void keyPressed(KeyEvent event) {
					int key=event.getKeyCode();
					if(key==10) {
						textField_38.requestFocus();
			}
		}});
		textField_35.setBounds(312, 238, 182, 20);
		panel_4.add(textField_35);
		textField_35.setColumns(10);
		
		textField_38 = new JTextField();
		textField_38.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_39.requestFocus();
			}
		}});
		textField_38.setColumns(10);
		textField_38.setBounds(312, 263, 182, 20);
		panel_4.add(textField_38);
		
		textField_39 = new JTextField();
		textField_39.addKeyListener(new KeyAdapter() {
			@Override
				public void keyPressed(KeyEvent event) {
					int key=event.getKeyCode();
					if(key==10) {
						textField_40.requestFocus();
			}
		}});
		textField_39.setColumns(10);
		textField_39.setBounds(312, 288, 182, 20);
		panel_4.add(textField_39);
		
		JDateChooser dateChooser_3 = new JDateChooser();
		dateChooser_3.setBounds(312, 339, 182, 20);
		panel_4.add(dateChooser_3);
		
		JComboBox comboBox_9 = new JComboBox();
		comboBox_9.setModel(new DefaultComboBoxModel(new String[] {"Select", "First Term", "Second Term", "Third Term"}));
		comboBox_9.setBounds(312, 312, 182, 20);
		panel_4.add(comboBox_9);
		
		JLabel lblSubject = new JLabel("Subjects");
		lblSubject.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblSubject.setBounds(10, 370, 97, 27);
		panel_4.add(lblSubject);
		
		JLabel lblEnterScore = new JLabel("Enter Score");
		lblEnterScore.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblEnterScore.setBounds(211, 370, 105, 27);
		panel_4.add(lblEnterScore);
		
		JSeparator separator_3_1 = new JSeparator();
		separator_3_1.setBackground(Color.LIGHT_GRAY);
		separator_3_1.setBounds(10, 394, 484, 2);
		panel_4.add(separator_3_1);
		
		JLabel lblMathematics = new JLabel("Mathematics");
		lblMathematics.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblMathematics.setBounds(10, 408, 97, 27);
		panel_4.add(lblMathematics);
		
		JLabel lblEnglish = new JLabel("English");
		lblEnglish.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblEnglish.setBounds(10, 433, 97, 27);
		panel_4.add(lblEnglish);
		
		JLabel lblChemistry = new JLabel("Chemistry");
		lblChemistry.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblChemistry.setBounds(10, 460, 97, 27);
		panel_4.add(lblChemistry);
		
		JLabel lblPhysics = new JLabel("Physics");
		lblPhysics.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblPhysics.setBounds(10, 487, 97, 27);
		panel_4.add(lblPhysics);
		
		JLabel lblBiology = new JLabel("Biology");
		lblBiology.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblBiology.setBounds(10, 514, 97, 27);
		panel_4.add(lblBiology);
		
		JLabel lblGeography = new JLabel("Geography");
		lblGeography.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblGeography.setBounds(10, 541, 97, 27);
		panel_4.add(lblGeography);
		
		JLabel lblFmathematics = new JLabel("F/Mathematics");
		lblFmathematics.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFmathematics.setBounds(10, 568, 114, 27);
		panel_4.add(lblFmathematics);
		
		JLabel lblGovernment = new JLabel("Government");
		lblGovernment.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblGovernment.setBounds(10, 593, 114, 27);
		panel_4.add(lblGovernment);
		
		JLabel lblBusinessStudies = new JLabel("Business Studies");
		lblBusinessStudies.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblBusinessStudies.setBounds(10, 625, 114, 27);
		panel_4.add(lblBusinessStudies);
		
		JLabel lblFinancialAccounting = new JLabel("Financial Accounting");
		lblFinancialAccounting.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblFinancialAccounting.setBounds(10, 652, 154, 27);
		panel_4.add(lblFinancialAccounting);
		
		JLabel lblCommerce = new JLabel("Commerce");
		lblCommerce.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblCommerce.setBounds(10, 678, 114, 27);
		panel_4.add(lblCommerce);
		
		JLabel lblComputer = new JLabel("Computer");
		lblComputer.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblComputer.setBounds(10, 703, 114, 27);
		panel_4.add(lblComputer);
		
		textField_40 = new JTextField();
		textField_40.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_40.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
					int key=event.getKeyCode();
					if(key==10) {
						textField_41.requestFocus();
			}
				
			}
		});
		textField_40.setColumns(10);
		textField_40.setBounds(211, 407, 97, 20);
		panel_4.add(textField_40);
		
		textField_41 = new JTextField();
		textField_41.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_42.requestFocus();
		}
			
		}
			
		});
		textField_41.setColumns(10);
		textField_41.setBounds(211, 437, 97, 20);
		panel_4.add(textField_41);
		
		textField_42 = new JTextField();
		textField_42.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_43.requestFocus();
		}
			
		}
		});
		textField_42.setColumns(10);
		textField_42.setBounds(211, 464, 97, 20);
		panel_4.add(textField_42);
		
		textField_43 = new JTextField();
		textField_43.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_44.requestFocus();
		}
			
		}
		});
		textField_43.setColumns(10);
		textField_43.setBounds(211, 491, 97, 20);
		panel_4.add(textField_43);
		
		textField_44 = new JTextField();
		textField_44.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_45.requestFocus();
		}
			
		}
		});
		textField_44.setColumns(10);
		textField_44.setBounds(211, 514, 97, 20);
		panel_4.add(textField_44);
		
		textField_45 = new JTextField();
		textField_45.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_46.requestFocus();
		}
			
		}

		});
		textField_45.setColumns(10);
		textField_45.setBounds(211, 541, 97, 20);
		panel_4.add(textField_45);
		
		textField_46 = new JTextField();
		textField_46.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_47.requestFocus();
		}
			
		}
		});
		textField_46.setColumns(10);
		textField_46.setBounds(211, 568, 97, 20);
		panel_4.add(textField_46);
		
		textField_47 = new JTextField();
		textField_47.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_48.requestFocus();
		}
			
		}
		});
		textField_47.setColumns(10);
		textField_47.setBounds(211, 593, 97, 20);
		panel_4.add(textField_47);
		
		textField_48 = new JTextField();
		textField_48.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_49.requestFocus();
		}
			
		}

		});
		textField_48.setColumns(10);
		textField_48.setBounds(211, 625, 97, 20);
		panel_4.add(textField_48);
		
		textField_49 = new JTextField();
		textField_49.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_50.requestFocus();
		}
			

			}
		});
		textField_49.setColumns(10);
		textField_49.setBounds(211, 652, 97, 20);
		panel_4.add(textField_49);
		
		textField_50 = new JTextField();
		textField_50.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_51.requestFocus();
		}
			
			}
		});
		textField_50.setColumns(10);
		textField_50.setBounds(211, 678, 97, 20);
		panel_4.add(textField_50);
		
		textField_51 = new JTextField();
		textField_51.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					textField_35.requestFocus();
		}
			
			}
		});
		textField_51.setColumns(10);
		textField_51.setBounds(211, 703, 97, 20);
		panel_4.add(textField_51);
		
		JSeparator separator_3_2 = new JSeparator();
		separator_3_2.setOrientation(SwingConstants.VERTICAL);
		separator_3_2.setBackground(Color.LIGHT_GRAY);
		separator_3_2.setBounds(497, 238, 2, 492);
		panel_4.add(separator_3_2);
		
		JSeparator separator_3_1_1 = new JSeparator();
		separator_3_1_1.setBackground(Color.LIGHT_GRAY);
		separator_3_1_1.setBounds(0, 728, 499, 2);
		panel_4.add(separator_3_1_1);
		
		JPanel panel_21 = new JPanel();
		panel_21.setBackground(Color.BLACK);
		panel_21.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Preview", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_21.setBounds(508, 48, 625, 497);
		panel_4.add(panel_21);
		panel_21.setLayout(null);
		
		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(6, 16, 613, 474);
		panel_21.add(scrollPane_6);
		
		textArea_4 = new JTextArea();
		textArea_4.setEditable(false);
		scrollPane_6.setViewportView(textArea_4);
		textArea_4.setLineWrap(true);
		
		JLabel lblResultSummary = new JLabel("Result Summary");
		lblResultSummary.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblResultSummary.setBounds(763, 545, 188, 27);
		panel_4.add(lblResultSummary);
		
		JSeparator separator_3_1_2 = new JSeparator();
		separator_3_1_2.setBackground(Color.LIGHT_GRAY);
		separator_3_1_2.setBounds(578, 568, 484, 2);
		panel_4.add(separator_3_1_2);
		
		JLabel lblTotalSubjectTaken = new JLabel("Total Subject Taken");
		lblTotalSubjectTaken.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblTotalSubjectTaken.setBounds(512, 587, 188, 27);
		panel_4.add(lblTotalSubjectTaken);
		
		JLabel lblTotalScoreObtain = new JLabel("Total Score For The Term");
		lblTotalScoreObtain.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblTotalScoreObtain.setBounds(512, 618, 188, 27);
		panel_4.add(lblTotalScoreObtain);
		
		JLabel lblTotalScoreObtained = new JLabel("Total Score Obtained");
		lblTotalScoreObtained.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblTotalScoreObtained.setBounds(512, 649, 188, 27);
		panel_4.add(lblTotalScoreObtained);
		
		JLabel lblAverageScore = new JLabel("Average Score");
		lblAverageScore.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblAverageScore.setBounds(512, 678, 188, 27);
		panel_4.add(lblAverageScore);
		
		JPanel panel_31 = new JPanel();
		panel_31.setBackground(Color.WHITE);
		panel_31.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, Color.WHITE));
		panel_31.setBounds(984, 580, 126, 150);
		panel_4.add(panel_31);
		panel_31.setLayout(null);
		
		JButton btnNewButton_3 = new JButton("Compute");
		btnNewButton_3.setBounds(6, 11, 110, 18);
		panel_31.add(btnNewButton_3);
		
		JButton btnNewButton_3_1 = new JButton("Preview");
		btnNewButton_3_1.setBounds(5, 34, 110, 18);
		panel_31.add(btnNewButton_3_1);
		
		JButton btnNewButton_3_1_1 = new JButton("Save");
		btnNewButton_3_1_1.setBounds(6, 61, 110, 18);
		panel_31.add(btnNewButton_3_1_1);
		
		JButton btnNewButton_3_2 = new JButton("Print");
		btnNewButton_3_2.setBounds(6, 90, 110, 18);
		panel_31.add(btnNewButton_3_2);
		
		JButton btnNewButton_3_2_1 = new JButton("Clear");
		btnNewButton_3_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField_35.setText(null);
				textField_38.setText(null);
				textField_39.setText(null);
				comboBox_9.setSelectedItem(null);
				dateChooser_3.setCalendar(null);
				textField_40.setText(null);
				textField_41.setText(null);
				textField_42.setText(null);
				textField_43.setText(null);
				textField_44.setText(null);
				textField_45.setText(null);
				textField_46.setText(null);
				textField_47.setText(null);
				textField_48.setText(null);
				textField_49.setText(null);
				textField_50.setText(null);
				textField_51.setText(null);
				textField_52.setText(null);
				textField_53.setText(null);
				textField_54.setText(null);
				textField_55.setText(null);
				textField_56.setText(null);
				textField_57.setText(null);
				textField_58.setText(null);
				textField_59.setText(null);
				textField_60.setText(null);
				textField_61.setText(null);
				textField_62.setText(null);
				textField_63.setText(null);
				textField_64.setText(null);
				textField_65.setText(null);
				textField_66.setText(null);
				textField_67.setText(null);
				textArea_4.setText(null);
				
			}
		});
		btnNewButton_3_2_1.setBounds(6, 121, 110, 18);
		panel_31.add(btnNewButton_3_2_1);
		btnNewButton_3_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					textArea_4.print();
				} catch (PrinterException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnNewButton_3_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(validateFieldsix()) {
				String sql="INSERT INTO resultdb(FirstName,MiddleName,LastName,Term,DateOfResumption,Mathematics,English,Chemistry,Physic,Biology,Geography,Fmathematics,Government,BusinessStudies,FinancialAccount,Commerce,Computer,SubjectTaken,ScoreForTerm,ScoreObtain,Average)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				try {
					pst=connection.prepareStatement(sql);
					pst.setString(1, textField_35.getText());
					pst.setString(2, textField_38.getText());
					pst.setString(3, textField_39.getText());
					String value=comboBox_9.getSelectedItem().toString();
					pst.setString(4, value);
					pst.setString(5, ((JTextField)dateChooser_3.getDateEditor().getUiComponent()).getText());
					pst.setString(6, textField_40.getText());
					pst.setString(7, textField_41.getText());
					pst.setString(8, textField_42.getText());
					pst.setString(9, textField_43.getText());
					pst.setString(10, textField_44.getText());
					pst.setString(11, textField_45.getText());
					pst.setString(12, textField_46.getText());
					pst.setString(13, textField_47.getText());
					pst.setString(14, textField_48.getText());
					pst.setString(15, textField_49.getText());
					pst.setString(16, textField_50.getText());
					pst.setString(17, textField_51.getText());
					pst.setString(18, textField_52.getText());
					pst.setString(19, textField_55.getText());
					pst.setString(20, textField_54.getText());
					pst.setString(21, textField_53.getText());
				
					pst.execute();
					JOptionPane.showMessageDialog(null, "inserted");
				}catch(Exception e) {
					JOptionPane.showMessageDialog(null, e);
				}
			}
		}});
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String name=textField_35.getText();
				String fname=textField_38.getText();
				String mname=textField_39.getText();
				String date=((JTextField)dateChooser_3.getDateEditor().getUiComponent()).getText();
				String mans=(String) comboBox_9.getSelectedItem();
		
				String math=textField_40.getText();
				String eng=textField_41.getText();
				String chm=textField_42.getText();
				String phy=textField_43.getText();
				String bio=textField_44.getText();
				String geo=textField_45.getText();
				String fm=textField_46.getText();
				String gov=textField_47.getText();
				String bu=textField_48.getText();
				String finance=textField_49.getText();
				String comm=textField_50.getText();
				String comp=textField_51.getText();
				String subject_taken=textField_52.getText();
				String score_term=textField_55.getText();
				String score_obtain=textField_54.getText();
				String average=textField_53.getText();
			    String m=textField_56.getText();
			    String e=textField_57.getText();
			    String c=textField_58.getText();
			    String p=textField_59.getText();
			    String b=textField_60.getText();
			    String g=textField_61.getText();
			    String fma=textField_62.getText();
			    String go=textField_63.getText();
			    String bs=textField_64.getText();
			    String fns=textField_65.getText();
			    String comerc=textField_66.getText();
			    String compu=textField_67.getText();
			   
				
				textArea_4.append("\n\t\tMYSCHOOL MANGEMENT SYSTEM"+"\n\t\t        STUDENT RESULT SHEET"+"\n\tNAME:- "+name+"  "+fname+"  "+mname+"\n\tDATE:- "+date+"\n\tTERM:- "+mans+"\n\tSUBJECT\t\tSCORE\t\tGRADE"
						+"\n\t1.MATHEMATICS\t                "+math+"\t\t           "+m+"\n\t2.ENGLISH LANGUAGE\t    "+eng+"\t                                "+e+"\n\t3.CHEMISTRY\t                      "+chm+"\t\t         "+c+"\n\t4.PHYSICS\t\t  "+phy+"\t\t           "+p
						+"\n\t5.BIOLOGY\t\t    "+bio+"\t\t     "+b+"\n\t6.GEOGRAPHY\t                      "+geo+"\t\t   "+g+"\n\t7.FURTHER MATHEMATICS\t"+fm+"\t\t    "+fma+"\n\t8.GOVERNMENT\t                      "+gov+"\t\t     "+go
						+"\n\t9.BUSINESS STUDIES\t             "+bu+"\t\t"+bs+"\n\t10.FINANCIAL ACCOUNTING\t"+finance+"\t\t"+fns+"\n\t11.COMMERCE\t\t"+comm+"\t\t"+comerc+"\n\t12.COMPUTER\t\t"+comp+"\t\t"+compu
						+"\n\n\tTOTAL SUBJECT TAKEN:-"+subject_taken+"\n\tTOTAL SCORE OBTAIN:-"+score_term+"\n\tTOTAL SCORE FOR THE TERM:-"+score_term+"\n\tAVERAGE SCORE:-"+average
						+"\n\tTEACHER COMMENT:-___________________________________________________"
						+"\n\tSIGNATURE:-___________________________________________________________");
			}  
		});
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(validateFieldfive()) {
				String mathtext=textField_40.getText();
				float math=Float.parseFloat(mathtext);
				String engtext=textField_41.getText();
				float eng=Float.parseFloat(engtext);
				String chmtext=textField_42.getText();
				float chm=Float.parseFloat(chmtext);
				String phytext=textField_43.getText();
				float phy=Float.parseFloat(phytext);
				String biotext=textField_44.getText();
				float bio=Float.parseFloat(biotext);
				String geotext=textField_45.getText();
				float geo=Float.parseFloat(geotext);
				String fmtext=textField_46.getText();
				float fm=Float.parseFloat(fmtext);
				String govtext=textField_47.getText();
				float gov=Float.parseFloat(govtext);
				String btext=textField_48.getText();
				float b=Float.parseFloat(btext);
				String fintext=textField_49.getText();
				float fin=Float.parseFloat(fintext);
				String comtext=textField_45.getText();
				float com=Float.parseFloat(comtext);
				String comptext=textField_45.getText();
				float comp=Float.parseFloat(comptext);
				float totals=math+eng+chm+phy+bio+geo+fm+gov+b+fin+com+comp;
				textField_52.setText("12");
				textField_55.setText("1200");
				textField_54.setText(""+totals);
				textField_53.setText(""+totals/12);
if(math>=70) {
					textField_56.setText("A");
				}else if(math>=60 && math<69)
				{ 
					textField_56.setText("B");
				}
				else if(math>=50 && math<59)
				{
					textField_56.setText("C");
				}
				else if(math>=45 && math<49)
				{
					textField_56.setText("D");
			}else if(math>=40 && math<44)
			{
				textField_56.setText("E");
				
				}else
				{
		 	textField_56.setText("F");
				}
if(eng>=70) {
					textField_57.setText("A");
				}else if(eng>=60 && eng<69)
				{ 
					textField_57.setText("B");
				}
				else if(eng>=50 && eng<59)
				{
					textField_57.setText("C");
				}
				else if(eng>=45 && eng<49)
				{
					textField_57.setText("D");
			}else if(eng>=40 && eng<44)
			{
				textField_57.setText("E");
				
				}else
				{
		 	textField_57.setText("F");
			}
if(chm>=70) {
	textField_58.setText("A");
}else if(chm>=60 && chm<69)
{ 
	textField_58.setText("B");
}
else if(chm>=50 && chm<59)
{
	textField_58.setText("C");
}
else if(chm>=45 && chm<49)
{
	textField_58.setText("D");
}else if(chm>=40 && chm<44)
{
textField_58.setText("E");

}else
{
textField_58.setText("F");
}
if(phy>=70) {
	textField_59.setText("A");
}else if(phy>=60 && phy<69)
{ 
	textField_59.setText("B");
}
else if(phy>=50 && phy<59)
{
	textField_59.setText("C");
}
else if(phy>=45 && phy<49)
{
	textField_59.setText("D");
}else if(phy>=40 && phy<44)
{
textField_59.setText("E");

}else
{
textField_59.setText("F");
}
if(bio>=70) {
	textField_60.setText("A");
}else if(bio>=60 && bio<69)
{ 
	textField_60.setText("B");
}
else if(bio>=50 && bio<59)
{
	textField_60.setText("C");
}
else if(bio>=45 && bio<49)
{
	textField_60.setText("D");
}else if(bio>=40 && bio<44)
{
textField_60.setText("E");

}else
{
textField_60.setText("F");
}
if(geo>=70) {
	textField_61.setText("A");
}else if(geo>=60 && geo<69)
{ 
	textField_61.setText("B");
}
else if(geo>=50 && geo<59)
{
	textField_61.setText("C");
}
else if(geo>=45 && geo<49)
{
	textField_61.setText("D");
}else if(geo>=40 && geo<44)
{
textField_61.setText("E");

}else
{
textField_61.setText("F");
}
if(fm>=70) {
	textField_62.setText("A");
}else if(fm>=60 && fm<69)
{ 
	textField_62.setText("B");
}
else if(fm>=50 && fm<59)
{
	textField_62.setText("C");
}
else if(fm>=45 && fm<49)
{
	textField_62.setText("D");
}else if(fm>=40 && fm<44)
{
textField_62.setText("E");

}else
{
textField_62.setText("F");
}
if(gov>=70) {
	textField_63.setText("A");
}else if(gov>=60 && gov<69)
{ 
	textField_63.setText("B");
}
else if(gov>=50 && gov<59)
{
	textField_63.setText("C");
}
else if(gov>=45 && gov<49)
{
	textField_63.setText("D");
}else if(gov>=40 && gov<44)
{
textField_63.setText("E");

}else
{
textField_63.setText("F");
}
if(b>=70) {
	textField_64.setText("A");
}else if(b>=60 && b<69)
{ 
	textField_64.setText("B");
}
else if(b>=50 && b<59)
{
	textField_64.setText("C");
}
else if(b>=45 && b<49)
{
	textField_64.setText("D");
}else if(b>=40 && b<44)
{
textField_64.setText("E");

}else
{
textField_64.setText("F");
}
if(fin>=70) {
	textField_65.setText("A");
}else if(fin>=60 && fin<69)
{ 
	textField_65.setText("B");
}
else if(fin>=50 && fin<59)
{
	textField_65.setText("C");
}
else if(fin>=45 && fin<49)
{
	textField_65.setText("D");
}else if(fin>=40 && fin<44)
{
textField_65.setText("E");

}else
{
textField_65.setText("F");
}
if(com>=70) {
	textField_66.setText("A");
}else if(com>=60 && com<69)
{ 
	textField_66.setText("B");
}
else if(com>=50 && com<59)
{
	textField_66.setText("C");
}
else if(com>=45 && com<49)
{
	textField_66.setText("D");
}else if(com>=40 && com<44)
{
textField_66.setText("E");

}else
{
textField_66.setText("F");
}
if(comp>=70) {
	textField_67.setText("A");
}else if(comp>=60 && comp<69)
{ 
	textField_67.setText("B");
}
else if(comp>=50 && comp<59)
{
	textField_67.setText("C");
}
else if(comp>=45 && comp<49)
{
	textField_67.setText("D");
}else if(comp>=40 && comp<44)
{
textField_67.setText("E");

}else
{
textField_67.setText("F");
}
				}}});
		
		textField_52 = new JTextField();
		textField_52.setEditable(false);
		textField_52.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_52.setColumns(10);
		textField_52.setBounds(782, 597, 182, 20);
		panel_4.add(textField_52);
		
		textField_53 = new JTextField();
		textField_53.setEditable(false);
		textField_53.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_53.setColumns(10);
		textField_53.setBounds(782, 682, 182, 20);
		panel_4.add(textField_53);
		
		textField_54 = new JTextField();
		textField_54.setEditable(false);
		textField_54.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_54.setColumns(10);
		textField_54.setBounds(782, 656, 182, 20);
		panel_4.add(textField_54);
		
		textField_55 = new JTextField();
		textField_55.setEditable(false);
		textField_55.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_55.setColumns(10);
		textField_55.setBounds(782, 629, 182, 20);
		panel_4.add(textField_55);
		
		textField_56 = new JTextField();
		textField_56.setEditable(false);
		textField_56.setColumns(10);
		textField_56.setBounds(376, 407, 97, 20);
		panel_4.add(textField_56);
		
		JLabel lblGrade = new JLabel("Grade");
		lblGrade.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblGrade.setBounds(398, 370, 105, 27);
		panel_4.add(lblGrade);
		
		textField_57 = new JTextField();
		textField_57.setEditable(false);
		textField_57.setColumns(10);
		textField_57.setBounds(376, 437, 97, 20);
		panel_4.add(textField_57);
		
		textField_58 = new JTextField();
		textField_58.setEditable(false);
		textField_58.setColumns(10);
		textField_58.setBounds(376, 464, 97, 20);
		panel_4.add(textField_58);
		
		textField_59 = new JTextField();
		textField_59.setEditable(false);
		textField_59.setColumns(10);
		textField_59.setBounds(376, 491, 97, 20);
		panel_4.add(textField_59);
		
		textField_60 = new JTextField();
		textField_60.setEditable(false);
		textField_60.setColumns(10);
		textField_60.setBounds(376, 518, 97, 20);
		panel_4.add(textField_60);
		
		textField_61 = new JTextField();
		textField_61.setEditable(false);
		textField_61.setColumns(10);
		textField_61.setBounds(376, 545, 97, 20);
		panel_4.add(textField_61);
		
		textField_62 = new JTextField();
		textField_62.setEditable(false);
		textField_62.setColumns(10);
		textField_62.setBounds(376, 572, 97, 20);
		panel_4.add(textField_62);
		
		textField_63 = new JTextField();
		textField_63.setEditable(false);
		textField_63.setColumns(10);
		textField_63.setBounds(376, 597, 97, 20);
		panel_4.add(textField_63);
		
		textField_64 = new JTextField();
		textField_64.setEditable(false);
		textField_64.setColumns(10);
		textField_64.setBounds(376, 629, 97, 20);
		panel_4.add(textField_64);
		
		textField_65 = new JTextField();
		textField_65.setEditable(false);
		textField_65.setColumns(10);
		textField_65.setBounds(376, 656, 97, 20);
		panel_4.add(textField_65);
		
		textField_66 = new JTextField();
		textField_66.setEditable(false);
		textField_66.setColumns(10);
		textField_66.setBounds(376, 682, 97, 20);
		panel_4.add(textField_66);
		
		textField_67 = new JTextField();
		textField_67.setEditable(false);
		textField_67.setColumns(10);
		textField_67.setBounds(376, 707, 97, 20);
		panel_4.add(textField_67);
		
		JSeparator separator_3_3 = new JSeparator();
		separator_3_3.setBackground(Color.LIGHT_GRAY);
		separator_3_3.setBounds(10, 370, 484, 2);
		panel_4.add(separator_3_3);
		
		JSeparator separator_3_1_3 = new JSeparator();
		separator_3_1_3.setBackground(Color.LIGHT_GRAY);
		separator_3_1_3.setBounds(10, 209, 484, 2);
		panel_4.add(separator_3_1_3);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome Admin");
		lblNewLabel_1.setForeground(Color.LIGHT_GRAY);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 400, 205, 34);
		frame.getContentPane().add(lblNewLabel_1);
		
}
}
