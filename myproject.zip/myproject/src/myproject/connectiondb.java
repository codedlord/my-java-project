package myproject;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class connectiondb {
Connection conn=null;
public static Connection dbconnect()
{
	try {
		Class.forName("org.sqlite.JDBC");
		Connection conn=DriverManager.getConnection("jdbc:sqlite:C:\\Users\\USER\\workstation\\myproject\\src\\myproject\\managementdb.db");
		JOptionPane.showMessageDialog(null, "connection successfull"); 
		return conn;
	}catch(Exception e) {
		JOptionPane.showMessageDialog(null, e);
		return null; 
		
	}
}

}