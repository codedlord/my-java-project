package myproject;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JProgressBar;
import java.awt.Color;
import java.awt.Font;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

public class sp extends JFrame {

	private JPanel contentPane;
	private static JProgressBar progressBar;
	private static JLabel lblNewLabel_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	int x;
					sp frame = new sp();
					frame.setVisible(true);
			try {
				for (x=0;x<=100;x++) {
					sp.progressBar.setValue(x);
					Thread.sleep(50);
					sp.lblNewLabel_2.setText(Integer.toString(x)+"%");
					if(x==100) {
						frame.dispose();
						logpage info= new logpage();
						logpage.main(null);
					}
				}
				
			}catch (InterruptedException e) {
				e.printStackTrace();
			}
		
	}

	/**
	 * Create the frame.
	 */
	public sp() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setUndecorated(true);
		setBounds(420, 250, 595, 304);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(102, 255, 102));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(4, 262, 585, 30);
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		contentPane.add(panel);
		panel.setLayout(null);
		
		progressBar = new JProgressBar();
		progressBar.setForeground(new Color(255, 51, 0));
		progressBar.setBounds(6, 5, 573, 20);
		panel.add(progressBar);
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(329, 219, 101, 32);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblMy = new JLabel("MY");
		lblMy.setBounds(262, 50, 101, 60);
		lblMy.setFont(new Font("Times New Roman", Font.BOLD, 60));
		contentPane.add(lblMy);
		
		JLabel lblNewLabel = new JLabel("SCHOOL");
		lblNewLabel.setBounds(185, 102, 262, 60);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 60));
		contentPane.add(lblNewLabel);
		
		JLabel lblLoading = new JLabel("Loading");
		lblLoading.setBounds(218, 219, 78, 32);
		lblLoading.setFont(new Font("Times New Roman", Font.BOLD, 20));
		contentPane.add(lblLoading);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 595, 54);
		panel_1.setBackground(new Color(153, 153, 255));
		contentPane.add(panel_1);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setBounds(0, 165, 595, 54);
		panel_1_1.setBackground(new Color(153, 255, 255));
		contentPane.add(panel_1_1);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(4, 249, 585, 2);
		contentPane.add(separator);
	}
}
