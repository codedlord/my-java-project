package myproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.UIManager;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.border.MatteBorder;

public class logpage {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField password;
	private JLabel lblUsername;
	private JLabel lblPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					logpage window = new logpage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public logpage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.setForeground(new Color(255, 255, 255));
		btnLogin.setBackground(new Color(192, 192, 192));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String pword=password.getText();
				String user=textField.getText();
				if(pword.contains("master")&&user.contains("master")) {
					password.setText(null);
					textField.setText(null);
					projectone info= new projectone();
					projectone.main(null);
					frame.setVisible(false);
					
						
				}else
				JOptionPane.showMessageDialog(null, "please contact the admin","invalid login details", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnLogin.setBounds(352, 424, 89, 34);
		frame.getContentPane().add(btnLogin);
		
		password = new JPasswordField();
		password.setBackground(Color.WHITE);
		password.setBounds(303, 360, 271, 20);
		frame.getContentPane().add(password);
		
		textField = new JTextField();
		textField.setBackground(Color.WHITE);
		textField.setBounds(300, 310, 274, 20);
		frame.getContentPane().add(textField);
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				int key=event.getKeyCode();
				if(key==10) {
					password.requestFocus();
				}
				
			}
		});
		textField.setColumns(10);
		
		JLabel lblSchoolManagement = new JLabel("SCHOOL MANAGEMENT");
		lblSchoolManagement.setHorizontalAlignment(SwingConstants.CENTER);
		lblSchoolManagement.setBounds(10, 11, 743, 36);
		frame.getContentPane().add(lblSchoolManagement);
		lblSchoolManagement.setForeground(Color.LIGHT_GRAY);
		lblSchoolManagement.setFont(new Font("Times New Roman", Font.BOLD, 30));
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\USER\\workstation\\myproject\\src\\myproject\\user-login-authenticate-icon-vector-260nw-1236250177.jpg"));
		lblNewLabel.setBounds(279, 58, 252, 241);
		frame.getContentPane().add(lblNewLabel);
		
		lblUsername = new JLabel("UserName");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblUsername.setBounds(118, 305, 125, 26);
		frame.getContentPane().add(lblUsername);
		
		lblPassword = new JLabel("PassWord");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPassword.setBounds(118, 354, 125, 26);
		frame.getContentPane().add(lblPassword);
		frame.setBounds(100, 100, 769, 508);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private void setBounds(int i, int j, int k, int l) {
		// TODO Auto-generated method stub
		
	}
}
